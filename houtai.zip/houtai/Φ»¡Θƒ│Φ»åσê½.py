import wave
from pyaudio import PyAudio,paInt16
import json
import base64
import os
import requests
import time
import os
import os
import subprocess
import wave, audioop
from pydub import AudioSegment
os.chdir('/Users/pangyuming/Desktop/test')

RATE = "16000"
FORMAT = "pcm"
CUID="wate_play"
DEV_PID="1536"

framerate=16000
NUM_SAMPLES=2000
channels=1
sampwidth=2
TIME=2

def get_token():
    server = "https://openapi.baidu.com/oauth/2.0/token?"
    grant_type = "client_credentials"
    #API Key
    client_id = "rFWaI0gKhnznQDHL9IlsG4OL"
    #Secret Key
    client_secret = "2qglftNSsTOaDiy8Z37STmzhBrs9sdNB"

    #拼url
    url ="%sgrant_type=%s&client_id=%s&client_secret=%s"%(server,grant_type,client_id,client_secret)
    #获取token
    res = requests.post(url)
    token = json.loads(res.text)["access_token"]
    return token
def get_word(token,i):
    with open(str(i)+'.pcm', "rb") as f:
        speech = base64.b64encode(f.read()).decode('utf8')
    size = os.path.getsize(str(i)+'.pcm')
    headers = { 'Content-Type' : 'application/json'}
    url = "https://vop.baidu.com/server_api"
    data={
            "format":FORMAT,
            "rate":RATE,
            "dev_pid":DEV_PID,
            "speech":speech,
            "cuid":CUID,
            "len":size,
            "channel":1,
            "token":token,
        }

    req = requests.post(url,json.dumps(data),headers)
    result = json.loads(req.text)
    return result

if __name__ == '__main__':
    current = os.getcwd()
    dirs = os.listdir(current)
    for i in dirs:
        if os.path.splitext(i)[1] == ".mp4":
            # bname = str(os.path.splitext(i)[0].encode('utf-8')).replace('\\','%').replace(' ','_')
            os.rename(i, 'temp.mp4')
            getwav = 'ffmpeg -i temp.mp4 -f wav -vn temp.wav'
            subprocess.call(getwav, shell=True)
            num=0
            audio = AudioSegment.from_wav('temp.wav')
            while(audio):
                audio[:60000].export(str(num)+'.wav', format="wav")
                get16kpcm = 'ffmpeg -y  -i '+str(num)+'.wav'+'  -acodec pcm_s16le -f s16le -ac 1 -ar 16000 '+str(num)+'.pcm'
                subprocess.call(get16kpcm, shell=True)
                os.remove(str(num)+'.wav')
                audio=audio[60000:]
                num+=1
            os.remove('temp.wav')
            text=''
            for j in range(num):
                token=get_token()
                try:
                    ret = get_word(token,j)
                    print(ret)
                    if 'result' in ret:
                        text+=ret['result'][0]
                except Exception as e:
                    print(e)
                os.remove(str(j)+'.pcm')
            f=open(os.path.splitext(i)[0]+'.txt','w',encoding='utf8')
            for line in text.split('。'):
                for newline in line.split('？'):
                    for newnewline in newline.split('，'):
                        f.write(newnewline+'\n')
            f.close()
            os.rename('temp.mp4',i)
