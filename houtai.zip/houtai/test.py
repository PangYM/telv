import json
import time
import random
from elasticsearch import Elasticsearch
import os
from pypinyin import lazy_pinyin

datapath = '/Users/pangyuming/Desktop/'
os.chdir(datapath)
import time


es = Elasticsearch([{"host": "localhost", "port": 9200, "timeout": 3600}])
search = {"query": {"match_all": {}}}
token_userid = {}
userid_token = {}
userid_zhanghao = {}
zhanghao_userid = {}
userinfo = {}
usertongxinlu = []
quanjusuo = 0


def updatausers():
    global usertongxinlu, userinfo, userid_zhanghao, zhanghao_userid
    tongxinluid = {}
    es.indices.refresh(index="userinfo")
    try:
        search = {"query": {"match_all": {}}}
        userdocs = es.search(index='userinfo', doc_type='userinfo', body=search, size=10000)
        userdocs = userdocs['hits']['hits']
        userinfo = {}
        userid_zhanghao = {}
        zhanghao_userid = {}
        for user in userdocs:
            userinfo[user['_source']['userid']] = user['_source']
        a = {}
        a['部门主管'] = {}
        a['部门主管']['id'] = '部门主管'
        a['部门主管']['pid'] = 'main'
        a['部门主管']['label'] = '部门主管'
        a['部门主管']['children'] = []
        a['部门主管']['quanxian'] = 20
        a['部门主管']['pinyin'] = 'bumenzhuguan'
        a['下属单位'] = {}
        a['下属单位'] = {}
        a['下属单位']['id'] = '下属单位'
        a['下属单位']['pid'] = 'main'
        a['下属单位']['label'] = '下属单位'
        a['下属单位']['children'] = []
        a['下属单位']['quanxian'] = 21
        a['下属单位']['pinyin'] = 'xiashudanwei'
        for user in userinfo:
            newuser = userinfo[user]
            newuser['group']=newuser['group'].strip()
            newuser['name'] = newuser['name'].strip()
            newuser['zhiweiname'] = newuser['zhiweiname'].strip()
            userid_zhanghao[newuser['userid']] = newuser['zhanghao']
            zhanghao_userid[newuser['zhanghao']] = newuser['userid']
            if newuser['group'] not in a:
                a[newuser['group']] = {}
                a[newuser['group']]['id'] = newuser['group']
                a[newuser['group']]['pid'] = 'main'
                a[newuser['group']]['label'] = newuser['group']
                a[newuser['group']]['children'] = []
                a[newuser['group']]['quanxian'] = 50
                pinyin = ''
                for word in lazy_pinyin(newuser['group']):
                    pinyin += word
                a[newuser['group']]['pinyin'] = pinyin
            if newuser['quanxian'] >= 28 and newuser['quanxian'] <= 30 and int(newuser['neiwai']) == 1:
                newid = str(random.randint(10000000000000, 99999999999999))
                while newid in tongxinluid:
                    newid = str(random.randint(10000000000000, 99999999999999))
                tongxinluid[newid] = 0
                b = {}
                b['id'] = newid
                b['userid'] = newuser['userid']
                b['pid'] = '部门主管'
                b['label'] = newuser['name'] + ' ' + newuser['zhiweiname']
                b['quanxian'] = int(newuser['quanxian'])
                b['children'] = []
                a['部门主管']['children'].append(b)
            if int(newuser['neiwai']) == 0:
                newid = str(random.randint(10000000000000, 99999999999999))
                while newid in tongxinluid:
                    newid = str(random.randint(10000000000000, 99999999999999))
                tongxinluid[newid] = 0
                b = {}
                b['id'] = newid
                b['userid'] = newuser['userid']
                b['pid'] = '下属单位'
                b['label'] = newuser['name'] + ' ' + newuser['zhiweiname']
                b['quanxian'] = int(newuser['quanxian'])
                b['children'] = []
                a['下属单位']['children'].append(b)
            b = {}
            b['id'] = newuser['userid']
            b['userid'] = newuser['userid']
            b['pid'] = newuser['group']
            b['label'] = newuser['name'] + ' ' + newuser['zhiweiname']
            b['quanxian'] = int(newuser['quanxian'])
            b['children'] = []
            a[newuser['group']]['children'].append(b)
            a[newuser['group']]['quanxian'] = min(a[newuser['group']]['quanxian'], (int(newuser['quanxian'])) - int(
                newuser['neiwai']))
        usertongxinlu = []
        c = []
        for d in a:
            c.append(a[d])
        for bumen in sorted(c, key=lambda x: (x['quanxian'], x['pinyin'])):
            bumen['children'] = sorted(bumen['children'], key=lambda x: (x['quanxian'], x['userid']))
            usertongxinlu.append(bumen)
        usertongxinlu = sorted(usertongxinlu, key=lambda x: x['pid'])
    except:
        None


# updatausers()


a="aaaaaaaaaaaaaaaaaa"
print(es.get(index='userinfo',doc_type='userinfo',id='dongyun')['_source']['pwd'])