import json
import time
import random
from elasticsearch import Elasticsearch
import os

datapath = '/Users/pangyuming/Desktop/tielv/data'
os.chdir(datapath)
import time


# f=open('test.json','r')
# content=''
# for line in f:
#     content+=line
# print(json.loads(content))

es = Elasticsearch([{"host": "localhost", "port": 9200, "timeout": 3600}])
es.delete(index='userinfo',doc_type='userinfo',id='nogjian')