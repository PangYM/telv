import json
import time
import random
from elasticsearch import Elasticsearch
import os

datapath = '/Users/pangyuming/Desktop/tielv/data'
os.chdir(datapath)
import time


# f=open('test.json','r')
# content=''
# for line in f:
#     content+=line
# print(json.loads(content))
es = Elasticsearch([{"host": "localhost", "port": 9200, "timeout": 3600}])
print(es.get(index='userinfo',doc_type='userinfo',id='yangliming')['_source'])


# es = Elasticsearch([{"host": "localhost", "port": 9200, "timeout": 3600}])
# search = {"query": {"match_all": {}}}
# Docs = es.search(index='jieshoumindoc', doc_type='jieshoumindoc', body=search, size=10000)
# Docs=Docs['hits']['hits']
# for doc in Docs:
#     docid=doc['_id']
#     doc=doc['_source']
#     data=json.loads(doc['data'])
#     for wendangid in data:
#         if len(wendangid)!=28:
#             print(wendangid)
#             print(docid)
