import json
import time
import random
from elasticsearch import Elasticsearch
import os

datapath = '/Users/pangyuming/Desktop/telv/data'
os.chdir(datapath)
import time

a='2019-04-23'
timeStamp = int(time.mktime(time.strptime(a, "%Y-%m-%d")))
print(timeStamp)
print(int(time.mktime(time.strptime(time.strftime("%Y-%m-%d", time.localtime()), "%Y-%m-%d"))))
print(3600*24)