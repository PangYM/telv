import json
import time
import random
from elasticsearch import Elasticsearch
import os

datapath = '/Users/pangyuming/Desktop/telv/data'
os.chdir(datapath)
a = []
b = {}
'''
客票服务部
广告管理事业部
主任业务员
计划财务部
投资设备部
下属单位负责人
单位公告账号
支部书记
人力资源部
策划推广部
法律事务部
党办
纪检检查员
团委
宣传助理
工会指导员
'''
b['id'] = 'jijingbuyuangong'
b['name'] = '集经部员工'
b['pwd'] = '123456'
b['phone'] = '15622146998'
b['dianhua'] = '15622146998'
b['email'] = '421542148@qq.com'
b['zhiweiname'] = '集经部员工'
b['group'] = '集经部'
b['quanxian'] = 50
a.append(b)


def add():
    f = open('userinfo.json', 'a', encoding='utf8')
    for line in a:
        f.write(json.dumps(line, ensure_ascii=False) + '\n')
    f.close()


def updata():
    f = open('userinfo.json', 'r', encoding='utf8')
    es = Elasticsearch([{"host": "localhost", "port": 9200, "timeout": 3600}])
    for line in f.readlines():
        if len(line) > 10:
            user = json.loads(line)
            try:
                doc = es.get(index='userinfo', doc_type='userinfo', id=user['id'])
                doc = doc['_source']
                doc.update(user)
                es.index(index='userinfo', doc_type='userinfo', id=user['id'], body=user)
            except:
                es.index(index='userinfo', doc_type='userinfo', id=user['id'], body=user)


def tongxinlu():
    es = Elasticsearch([{"host": "localhost", "port": 9200, "timeout": 3600}])
    search = {"query": {"match_all": {}}}
    Docs = es.search(index='userinfo', doc_type='userinfo', body=search, size=10000)
    a = {}
    a['行政领导'] = {}
    a['行政领导']['id'] = '行政领导'
    a['行政领导']['pid'] = 'main'
    a['行政领导']['label'] = '行政领导'
    a['行政领导']['children'] = []
    a['部门主管'] = {}
    a['部门主管']['id'] = '部门主管'
    a['部门主管']['pid'] = 'main'
    a['部门主管']['label'] = '部门主管'
    a['部门主管']['children'] = []
    chongfu = {}
    for doc in Docs['hits']['hits']:
        doc = doc['_source']
        if doc['group'] not in a:
            a[doc['group']] = {}
            a[doc['group']]['id'] = doc['group']
            a[doc['group']]['pid'] = 'main'
            a[doc['group']]['label'] = doc['group']
            a[doc['group']]['children'] = []
        b = {}
        b['id'] = doc['id']
        b['userid'] = doc['id']
        b['pid'] = doc['group']
        b['label'] = doc['name'] + ' ' + doc['zhiweiname']
        b['quanxian'] = doc['quanxian']
        b['children'] = []
        a[doc['group']]['children'].append(b)
    c = []
    for bumen in a:
        d = a[bumen]
        d['children'] = sorted(d['children'], key=lambda x: x['quanxian'])
        c.append(d)
    f = open('tongxinlu.json', 'w', encoding='utf8')
    f.write(json.dumps(c, ensure_ascii=False) + '\n')
    f.close()


updata()
# tongxinlu()