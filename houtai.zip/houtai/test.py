import json
import time
import random
from elasticsearch import Elasticsearch
import os
from pypinyin import lazy_pinyin

datapath = '/Users/pangyuming/Desktop/'
os.chdir(datapath)
import time,datetime


# es = Elasticsearch([{"host": "localhost", "port": 9200, "timeout": 3600}])
# search = {"query": {"match_all": {}}}
#
# t=0
# Docs=es.search(index='wendang',doc_type='wendang',body=search,size=10000)['hits']['hits']
# for doc in Docs:
#     doc=doc['_source']
#     wendangid=doc['wendangid']
#     shenpihis=json.loads(doc['shenpihis'])
#     for userid in shenpihis:
#         newdoc=es.get(index='jieshouwendang',doc_type='jieshouwendang',id=userid)['_source']
#         data=json.loads(newdoc['data'])
#         if wendangid in data:
#             if shenpihis[userid]['wancheng']!=data[wendangid]['wancheng']:
#                 if wendangid=='2019071811030739240182045221':
#                     for liucheng in doc['liuchenglist']:
#                         print(liucheng)
#                     print(shenpihis[userid]['wancheng'],data[wendangid]['wancheng'],userid,shenpihis[userid],wendangid)
#                     print(doc)
#                 t+=1
# print(t)

print(time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(1569344523)))