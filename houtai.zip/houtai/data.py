from elasticsearch import Elasticsearch
from elasticsearch import helpers
import csv
import os
import time
import json
import random
import requests

datapath = '/Users/pangyuming/Desktop/telv/data/'
os.chdir(datapath)
blocklen = 500


class Lianaizhuli_ES:
    es = Elasticsearch([{"host": "localhost", "port": 9200, "timeout": 3600}])
    def __init__(self):
        # self.es.indices.delete(index='userinfo')
        self.es.indices.delete(index='wendang')
        self.es.indices.delete(index='jieshouwendang')
        self.es.indices.delete(index='mindoc')
        self.es.indices.delete(index='jieshoumindoc')
        self.es.indices.delete(index='bumenwenjian')
        self.es.indices.delete(index='changyongzu')
        if self.es.indices.exists(index='bumenwenjian') is not True:
            _index = {
                "settings": {
                    "number_of_shards": 1,
                    "number_of_replicas": 1,
                },
                "mapping":{
                    "date_detection":False,
                },
                "properties": {
                    "title": {
                        "type": "text",
                        "fields": {
                            "cn": {
                                "type": "text",
                                "analyzer": "ik_smart"
                            },
                            "en": {
                                "type": "text",
                                "analyzer": "english"
                            }
                        }
                    }
                }
            }
            # ret_userinfo = self.es.indices.create(index='userinfo', body=_index, ignore=400)
            # print(ret_userinfo)
            ret_userinfo = self.es.indices.create(index='wendang', body=_index, ignore=400)
            print(ret_userinfo)
            ret_userinfo = self.es.indices.create(index='jieshouwendang', body=_index, ignore=400)
            print(ret_userinfo)
            ret_userinfo = self.es.indices.create(index='mindoc', body=_index, ignore=400)
            print(ret_userinfo)
            ret_userinfo = self.es.indices.create(index='jieshoumindoc', body=_index, ignore=400)
            print(ret_userinfo)
            ret_userinfo = self.es.indices.create(index='bumenwenjian', body=_index, ignore=400)
            print(ret_userinfo)
            ret_userinfo = self.es.indices.create(index='changyongzu', body=_index, ignore=400)
            print(ret_userinfo)
            actions = []
            # with open('userinfo.json', 'r',encoding='utf8') as f:
            #     for line in f:
            #         item = json.loads(line.strip())
            #         action = {
            #             "_index": "userinfo",
            #             "_type": "userinfo",
            #             "_source": item,
            #             '_id':item['id']
            #         }
            #         actions.append(action)
            # random.shuffle(actions)
            # while len(actions):
            #     helpers.bulk(self.es, actions[:blocklen])
            #     actions = actions[blocklen:]
            print('创建结束！')

    def add(self):
        return None

    def delete(self):
        return None

    def updata(self):
        return None

LAES=Lianaizhuli_ES()