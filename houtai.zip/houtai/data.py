from elasticsearch import Elasticsearch
from elasticsearch import helpers
import csv
import os
import time
import json
import random
import requests

datapath = '/Users/pangyuming/Desktop/'
os.chdir(datapath)
blocklen = 500
es = Elasticsearch([{"host": "localhost", "port": 9200, "timeout": 3600}])
# es.indices.delete(index='userinfo')
# es.indices.delete(index='wendang')
# es.indices.delete(index='jieshouwendang')
# es.indices.delete(index='mindoc')
# es.indices.delete(index='jieshoumindoc')
# es.indices.delete(index='bumenwenjian')
# es.indices.delete(index='changyongzu')
if es.indices.exists(index='wendang') is not True:
    _index = {
        "settings": {
            "number_of_shards": 1,
            "number_of_replicas": 1,
        },
        "mapping":{
            "date_detection":False,
        },
        "properties": {
            "title": {
                "type": "text",
                "fields": {
                    "cn": {
                        "type": "text",
                        "analyzer": "ik_smart"
                    },
                    "en": {
                        "type": "text",
                        "analyzer": "english"
                    }
                }
            }
        }
    }
    # ret_userinfo = es.indices.create(index='userinfo', body=_index, ignore=400)
    # print(ret_userinfo)
    # ret_userinfo = es.indices.create(index='wendang', body=_index, ignore=400)
    # print(ret_userinfo)
    # ret_userinfo = es.indices.create(index='jieshouwendang', body=_index, ignore=400)
    # print(ret_userinfo)
    # ret_userinfo = es.indices.create(index='mindoc', body=_index, ignore=400)
    # print(ret_userinfo)
    # ret_userinfo = es.indices.create(index='jieshoumindoc', body=_index, ignore=400)
    # print(ret_userinfo)
    # ret_userinfo = es.indices.create(index='bumenwenjian', body=_index, ignore=400)
    # print(ret_userinfo)
    # ret_userinfo = es.indices.create(index='changyongzu', body=_index, ignore=400)
    # print(ret_userinfo)
    print('创建结束！')

# namename='wendang'
# search = {"query": {"match_all": {}}}
# Docs = es.search(index=namename, doc_type=namename, body=search, size=10000)['hits']['hits']
# f=open(namename+'.json','w')
# for doc in Docs:
#     f.write(json.dumps(doc,ensure_ascii=False)+'\n')
# f.close()