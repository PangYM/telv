from elasticsearch import Elasticsearch
from elasticsearch import helpers
import csv
import os
import time
import json
import random
import requests

datapath = '/Users/pangyuming/Desktop/tielv/data'
os.chdir(datapath)
blocklen = 500
es = Elasticsearch([{"host": "localhost", "port": 9200, "timeout": 3600}])
es.indices.delete(index='userinfo')
es.indices.delete(index='wendang')
es.indices.delete(index='jieshouwendang')
es.indices.delete(index='mindoc')
es.indices.delete(index='jieshoumindoc')
es.indices.delete(index='bumenwenjian')
es.indices.delete(index='changyongzu')
# es.indices.delete(index='lingdaopishilist')
if es.indices.exists(index='wendang') is not True:
    _index = {
        "settings": {
            "number_of_shards": 1,
            "number_of_replicas": 1,
        },
        "properties": {
            "title": {
                "type": "text",
                "fields": {
                    "cn": {
                        "type": "text",
                        "analyzer": "ik_smart"
                    },
                    "en": {
                        "type": "text",
                        "analyzer": "english"
                    }
                }
            }
        }
    }
    ret_userinfo = es.indices.create(index='userinfo', body=_index, ignore=400)
    print(ret_userinfo)
    ret_userinfo = es.indices.create(index='wendang', body=_index, ignore=400)
    print(ret_userinfo)
    ret_userinfo = es.indices.create(index='jieshouwendang', body=_index, ignore=400)
    print(ret_userinfo)
    ret_userinfo = es.indices.create(index='mindoc', body=_index, ignore=400)
    print(ret_userinfo)
    ret_userinfo = es.indices.create(index='jieshoumindoc', body=_index, ignore=400)
    print(ret_userinfo)
    ret_userinfo = es.indices.create(index='bumenwenjian', body=_index, ignore=400)
    print(ret_userinfo)
    ret_userinfo = es.indices.create(index='changyongzu', body=_index, ignore=400)
    print(ret_userinfo)
    # ret_userinfo = es.indices.create(index='lingdaopishilist', body=_index, ignore=400)
    # print(ret_userinfo)
    actions=[]
    with open('userinfo.json', 'r') as f:
        for line in f:
            item = json.loads(line.strip())
            action = {
                "_index": "userinfo",
                "_type": "userinfo",
                '_id': item['_id'],
                "_source": item['_source']
            }
            actions.append(action)
    random.shuffle(actions)
    while len(actions):
        helpers.bulk(es, actions[:blocklen])
        actions = actions[blocklen:]
    with open('changyongzu.json', 'r') as f:
        for line in f:
            item = json.loads(line.strip())
            action = {
                "_index": "changyongzu",
                "_type": "changyongzu",
                '_id': item['_id'],
                "_source": item['_source']
            }
            actions.append(action)
    random.shuffle(actions)
    while len(actions):
        helpers.bulk(es, actions[:blocklen])
        actions = actions[blocklen:]
    with open('bumenwenjian.json', 'r') as f:
        for line in f:
            item = json.loads(line.strip())
            action = {
                "_index": "bumenwenjian",
                "_type": "bumenwenjian",
                '_id': item['_id'],
                "_source": item['_source']
            }
            actions.append(action)
    random.shuffle(actions)
    while len(actions):
        helpers.bulk(es, actions[:blocklen])
        actions = actions[blocklen:]
    with open('wendang.json', 'r') as f:
        for line in f:
            item = json.loads(line.strip())
            action = {
                "_index": "wendang",
                "_type": "wendang",
                '_id': item['_id'],
                "_source": item['_source']
            }
            actions.append(action)
    random.shuffle(actions)
    while len(actions):
        helpers.bulk(es, actions[:blocklen])
        actions = actions[blocklen:]
    with open('jieshouwendang.json', 'r') as f:
        for line in f:
            item = json.loads(line.strip())
            action = {
                "_index": "jieshouwendang",
                "_type": "jieshouwendang",
                '_id': item['_id'],
                "_source": item['_source']
            }
            actions.append(action)
    random.shuffle(actions)
    while len(actions):
        helpers.bulk(es, actions[:blocklen])
        actions = actions[blocklen:]
    with open('mindoc.json', 'r') as f:
        for line in f:
            item = json.loads(line.strip())
            action = {
                "_index": "mindoc",
                "_type": "mindoc",
                '_id': item['_id'],
                "_source": item['_source']
            }
            actions.append(action)
    random.shuffle(actions)
    while len(actions):
        helpers.bulk(es, actions[:blocklen])
        actions = actions[blocklen:]
    with open('jieshoumindoc.json', 'r') as f:
        for line in f:
            item = json.loads(line.strip())
            action = {
                "_index": "jieshoumindoc",
                "_type": "jieshoumindoc",
                '_id': item['_id'],
                "_source": item['_source']
            }
            actions.append(action)
    random.shuffle(actions)
    while len(actions):
        helpers.bulk(es, actions[:blocklen])
        actions = actions[blocklen:]
    print('创建结束！')



