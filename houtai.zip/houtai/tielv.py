# from gevent import monkey
from gevent import pywsgi
# monkey.patch_all()
import shutil
import csv
from flask import Flask
from flask import request
import json
import time
import random
from flask_cors import *
import os
from elasticsearch import Elasticsearch
import logging

app = Flask(__name__)
app.debug = True
CORS(app, supports_credentials=True)

datapath = '/Users/pangyuming/Desktop/tielv/data/'
datapathcopy = '/Users/pangyuming/Desktop/tielv/datacopy/'
os.chdir(datapath)
logger = logging.getLogger(__name__)
logger.setLevel(level=logging.INFO)
handler = logging.FileHandler("log/log.txt")
handler.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(funcName)s - %(name)s - %(levelname)s - %(message)s')
handler.setFormatter(formatter)
logger.addHandler(handler)
es = Elasticsearch([{"host": "localhost", "port": 9200, "timeout": 3600}])
token_userid = {}
userid_token = {}
userid_zhanghao = {}
zhanghao_userid = {}
userinfo = {}
usertongxinlu = []
quanjusuo = 0


def updatausers():
    logger.info("开始")
    global usertongxinlu, userinfo, userid_zhanghao, zhanghao_userid
    tongxinluid={}
    try:
        search = {"query": {"match_all": {}}}
        userdocs = es.search(index='userinfo', doc_type='userinfo', body=search, size=10000)
        userdocs = userdocs['hits']['hits']
        userinfo = {}
        userid_zhanghao = {}
        zhanghao_userid = {}
        for user in userdocs:
            userinfo[user['_source']['userid']] = user['_source']
        a = {}
        a['部门负责人']={}
        a['部门负责人']['id'] = '部门负责人'
        a['部门负责人']['pid'] = 'main'
        a['部门负责人']['label'] = '部门负责人'
        a['部门负责人']['children'] = []
        a['部门负责人']['quanxian'] = 20
        a['下属单位']={}
        a['下属单位'] = {}
        a['下属单位']['id'] = '下属单位'
        a['下属单位']['pid'] = 'main'
        a['下属单位']['label'] = '下属单位'
        a['下属单位']['children'] = []
        a['下属单位']['quanxian'] = 21
        for user in userinfo:
            newuser = userinfo[user]
            userid_zhanghao[newuser['userid']] = newuser['zhanghao']
            zhanghao_userid[newuser['zhanghao']] = newuser['userid']
            if newuser['group'] not in a:
                a[newuser['group']] = {}
                a[newuser['group']]['id'] = newuser['group']
                a[newuser['group']]['pid'] = 'main'
                a[newuser['group']]['label'] = newuser['group']
                a[newuser['group']]['children'] = []
                a[newuser['group']]['quanxian'] = 50
            if newuser['quanxian']>=28 and newuser['quanxian']<=30 and int(newuser['neiwai'])==1:
                newid=str(random.randint(10000000000000, 99999999999999))
                while newid in tongxinluid:
                    newid = str(random.randint(10000000000000, 99999999999999))
                tongxinluid[newid]=0
                b = {}
                b['id'] = newid
                b['userid'] = newuser['userid']
                b['pid'] = newuser['group']
                b['label'] = newuser['name'] + ' ' + newuser['zhiweiname']
                b['quanxian'] = int(newuser['quanxian'])
                b['children'] = []
                a['部门负责人']['children'].append(b)
            if int(newuser['neiwai'])==0:
                newid=str(random.randint(10000000000000, 99999999999999))
                while newid in tongxinluid:
                    newid = str(random.randint(10000000000000, 99999999999999))
                tongxinluid[newid]=0
                b = {}
                b['id'] = newid
                b['userid'] = newuser['userid']
                b['pid'] = newuser['group']
                b['label'] = newuser['name'] + ' ' + newuser['zhiweiname']
                b['quanxian'] = int(newuser['quanxian'])
                b['children'] = []
                a['下属单位']['children'].append(b)
            b = {}
            b['id'] = newuser['userid']
            b['userid'] = newuser['userid']
            b['pid'] = newuser['group']
            b['label'] = newuser['name'] + ' ' + newuser['zhiweiname']
            b['quanxian'] = int(newuser['quanxian'])
            b['children'] = []
            a[newuser['group']]['children'].append(b)
            a[newuser['group']]['quanxian'] = min(a[newuser['group']]['quanxian'], int(newuser['quanxian']))
        # print('aaaaaaaaaaaaaaaaaaaaaaaaaaaaa')
        usertongxinlu = []
        c = []
        for d in a:
            c.append(a[d])
        for bumen in sorted(c, key=lambda x: (x['quanxian'],x['label'])):
            bumen['children'] = sorted(bumen['children'], key=lambda x: (x['quanxian'], x['userid']))
            usertongxinlu.append(bumen)
        usertongxinlu = sorted(usertongxinlu, key=lambda x: x['pid'])
    except Exception as e:
        logger.error(e)


updatausers()
for line in open(datapath + 'token.json', 'r'):
    userid_token = json.loads(line)
    break
for userid in userid_token:
    token_userid[userid_token[userid]] = userid


@app.route('/api/userLogin', methods=['POST'])
def userLogin():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    zhanghao = parms['zhanghao']
    pwd = parms['pwd']
    try:
        userid = zhanghao_userid[zhanghao]
        doc = es.get(index='userinfo', doc_type='userinfo', id=userid)
        doc = doc['_source']
        token = ''
        if doc['pwd'] == pwd:
            if userid in userid_token:
                token = userid_token[userid]
                token_userid.pop(token)
            token = str(time.strftime("%Y%m%d%H%M%S", time.localtime())) + str(
                random.randint(10000000000000, 99999999999999))
            userid_token[userid] = token
            token_userid[token] = userid
            f = open(datapath + 'token.json', 'w', encoding='utf8')
            f.write(json.dumps(userid_token))
            f.close()
            logger.info("结束")
            print(doc)
            return json.dumps({'MSG': 'YES', 'token': token, 'userdata': doc})
        else:
            logger.info("结束")
            return json.dumps({'MSG': 'NO'})
    except Exception as e:
        logger.info("密码不正确")
        logger.info("结束")
        return json.dumps({'MSG': 'NO'})


@app.route('/api/getUser', methods=['POST'])
def getUser():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    if 'zhanghao' not in parms:
        logger.info("结束")
        return json.dumps({'MSG': 'YES', 'userinfo': userinfo[userid]})
    if userid in userinfo and userinfo[userid]['quanxian'] != 60 and userinfo[userid]['quanxian'] != 28:
        logger.info("结束")
        return json.dumps({'MSG': 'NO'})
    zhanghao = parms['zhanghao']
    userid = zhanghao_userid[zhanghao]
    logger.info("结束")
    return json.dumps({'MSG': 'YES', 'userinfo': userinfo[userid]})


@app.route('/api/setUserProfile', methods=['POST'])
def setUserProfile():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    userid = parms['userid']
    newzhanghao = parms['zhanghao']
    newzhanghao = newzhanghao.strip()
    zhanghao = ''
    for zimu in newzhanghao:
        if zimu != ' ':
            zhanghao += zimu
    if userid != zhanghao:
        if zhanghao in zhanghao_userid:
            logger.info("结束")
            return json.dumps({'MSG': 'NO'})
        else:
            oldzhanghao = userid_zhanghao[userid]
            zhanghao_userid.pop(oldzhanghao)
            userid_zhanghao[userid] = zhanghao
            zhanghao_userid[zhanghao] = userid
    doc = es.get(index='userinfo', doc_type='userinfo', id=userid)['_source']
    parms['quanxian'] = int(parms['quanxian'])
    doc.update(parms)
    es.index(index='userinfo', doc_type='userinfo', id=userid, body=doc, timeout=1)
    updatausers()
    logger.info("结束")
    return json.dumps({'MSG': 'YES', 'userdata': userinfo[userid]})


@app.route('/api/gettouxiangUrl', methods=['POST'])
def gettouxiangUrl():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    doc = es.get(index='userinfo', doc_type='userinfo', id=userid)
    doc = doc['_source']
    touxiangUrl = ''
    if 'touxiangUrl' in doc:
        touxiangUrl = doc['touxiangUrl']
    logger.info("结束")
    return json.dumps({'touxiangUrl': touxiangUrl})


@app.route('/api/settouxiangUrl', methods=['POST'])
def settouxiangUrl():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    doc = es.get(index='userinfo', doc_type='userinfo', id=userid)
    doc = doc['_source']
    retdata = ''
    if 'touxiangUrl' in doc and doc['touxiangUrl'] != '' and 'touxiangUrlfu' in doc and doc['touxiangUrl'] != doc[
        'touxiangUrlfu']:
        try:
            os.remove(datapath + '/' + doc['touxiangUrl'])
            os.remove(datapathcopy + '/' + doc['touxiangUrl'])
        except Exception as e:
            logger.error(e)
    if 'touxiangUrlfu' in doc:
        doc['touxiangUrl'] = doc['touxiangUrlfu']
        retdata = doc['touxiangUrl']
    es.index(index='userinfo', doc_type='userinfo', id=userid, body=doc)
    updatausers()
    logger.info("结束")
    return json.dumps({'touxiangUrl': retdata})


@app.route('/api/getqianmingUrl', methods=['POST'])
def getqianmingUrl():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    doc = es.get(index='userinfo', doc_type='userinfo', id=userid)
    doc = doc['_source']
    qianmingUrl = ''
    if 'qianmingUrl' in doc:
        qianmingUrl = doc['qianmingUrl']
    logger.info("结束")
    return json.dumps({'qianmingUrl': qianmingUrl})


@app.route('/api/setqianmingUrl', methods=['POST'])
def setqianmingUrl():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    doc = es.get(index='userinfo', doc_type='userinfo', id=userid)
    doc = doc['_source']
    retdata = ''
    if 'qianmingUrl' in doc and doc['qianmingUrl'] != '' and 'qianmingUrlfu' in doc and doc['qianmingUrl'] != doc[
        'qianmingUrlfu']:
        try:
            os.remove(datapath + '/' + doc['qianmingUrl'])
            os.remove(datapathcopy + '/' + doc['qianmingUrl'])
        except Exception as e:
            logger.error(e)
    if 'qianmingUrlfu' in doc:
        doc['qianmingUrl'] = doc['qianmingUrlfu']
        retdata = doc['qianmingUrl']
    es.index(index='userinfo', doc_type='userinfo', id=userid, body=doc)
    updatausers()
    logger.info("结束")
    return json.dumps({'qianmingUrl': retdata})


@app.route('/api/touxiangUrl', methods=['POST'])
def touxiangUrl():
    logger.info("开始")
    upload_file = request.files['file']
    token = request.form['token']
    userid = token_userid[token]
    doc = es.get(index='userinfo', doc_type='userinfo', id=userid)
    doc = doc['_source']
    name = 'touxiang/' + userid + '_' + str(random.randint(10000000000000, 99999999999999)) + '.jpg'
    if 'touxiangUrlfu' in doc and doc['touxiangUrlfu'] != '' and 'touxiangUrl' in doc and doc['touxiangUrlfu'] != doc[
        'touxiangUrl']:
        try:
            os.remove(datapath + '/' + doc['touxiangUrlfu'])
            os.remove(datapathcopy + '/' + doc['touxiangUrlfu'])
        except Exception as e:
            logger.error(e)
    doc['touxiangUrlfu'] = name
    es.index(index='userinfo', doc_type='userinfo', id=userid, body=doc)
    upload_file.save(datapath + name)
    open(datapathcopy + name, "wb").write(open(name, "rb").read())
    logger.info("结束")
    return "OK"


@app.route('/api/qianmingUrl', methods=['POST'])
def qianmingUrl():
    logger.info("开始")
    upload_file = request.files['file']
    token = request.form['token']
    userid = token_userid[token]
    doc = es.get(index='userinfo', doc_type='userinfo', id=userid)
    doc = doc['_source']
    name = 'qianming/' + userid + '_' + str(random.randint(10000000000000, 99999999999999)) + '.jpg'
    if 'qianmingUrlfu' in doc and doc['qianmingUrlfu'] != '' and 'qianmingUrl' in doc and doc['qianmingUrlfu'] != doc[
        'qianmingUrl']:
        try:
            os.remove(datapath + '/' + doc['qianmingUrlfu'])
            os.remove(datapathcopy + '/' + doc['qianmingUrlfu'])
        except Exception as e:
            logger.error(e)
    doc['qianmingUrlfu'] = name
    es.index(index='userinfo', doc_type='userinfo', id=userid, body=doc)
    upload_file.save(datapath + name)
    open(datapathcopy + name, "wb").write(open(name, "rb").read())
    logger.info("结束")
    return "OK"


@app.route('/api/changepwd', methods=['POST'])
def changepwd():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    doc = es.get(index='userinfo', doc_type='userinfo', id=userid)
    doc = doc['_source']
    if doc['pwd'] != parms['oldPwd']:
        logger.info("结束")
        return json.dumps({'MSG': 'NO'})
    doc['pwd'] = parms['newPwd']
    es.index(index='userinfo', doc_type='userinfo', id=userid, body=doc)
    updatausers()
    logger.info("结束")
    return json.dumps({'MSG': 'YES'})


@app.route('/api/getfawenhao', methods=['POST'])
def getfawenhao():
    logger.info("开始")
    wendangid = time.strftime("%Y%m%d%H%M%S", time.localtime())
    suiji = str(random.randint(10000000000000, 99999999999999))
    while 1:
        try:
            es.get(index='wendang', doc_type='wendang', id=wendangid + suiji)
            suiji = str(random.randint(10000000000000, 99999999999999))
        except:
            break
    logger.info("结束")
    return json.dumps({'wendangid': wendangid, 'suiji': suiji})


@app.route('/api/baocunfujian', methods=['POST'])
def baocunfujian():
    logger.info("开始")
    upload_file = request.files['file']
    wendangid = request.form.get('wendangid')
    isExists = os.path.exists(datapath + 'fujian/' + wendangid)
    if not isExists:
        os.makedirs('fujian/' + wendangid)
        os.makedirs(datapathcopy + 'fujian/' + wendangid)
    name = 'fujian/' + wendangid + '/' + upload_file.filename
    upload_file.save(datapath + name)
    open(datapathcopy + name, "wb").write(open(name, "rb").read())
    logger.info("结束")
    return "OK"


@app.route('/api/fasongwendang', methods=['POST'])
def fasongwendang():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    wendang = parms['wendang']
    if len(wendang['biaoti']) == 0:
        wendang['biaoti'] = '空'
    wendangid = wendang['wendangid']
    try:
        doc = es.get(index='wendang', doc_type='wendang', id=wendangid)['_source']
        if doc['shenpihis'][userid]['wancheng'] == 1:
            wendang = doc
    except Exception as e:
        logger.info(e)
    toData = parms['toData']
    nowtime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    if 'starttime' not in wendang:
        wendang['starttime'] = nowtime
        isExists = os.path.exists('fujian/' + wendangid)
        if isExists:
            for root, dirs, files in os.walk(os.path.join(datapath, 'fujian/' + wendangid)):
                for file in files:
                    flag = 1
                    for fujian in wendang['fileList']:
                        if fujian['name'] == file:
                            flag = 0
                    if flag:
                        try:
                            os.remove(os.path.join(root, file))
                            os.remove(datapathcopy + 'fujian/' + wendangid + '/' + file)
                        except Exception as e:
                            logger.error(e)
    shenpihis = wendang['shenpihis']
    liuchenglist = wendang['liuchenglist']
    if len(toData):
        if len(shenpihis) == 0:
            shenpi = {}
            shenpi['name'] = userinfo[wendang['nigaouserid']]['name']
            shenpi['laiwenuserid'] = wendang['nigaouserid']
            shenpi['laiwenren'] = userinfo[wendang['nigaouserid']]['name']
            shenpi['laiwentime'] = nowtime
            shenpi['endtime'] = nowtime
            shenpi['caozuo'] = '未完成'
            shenpi['wancheng'] = 1
            shenpi['cishu'] = 0
            if userinfo[userid]['quanxian'] < 40:
                shenpi['cishu'] = 1
            shenpihis[wendang['nigaouserid']] = shenpi
            liucheng = {}
            liucheng['userid'] = wendang['nigaouserid']
            liucheng['name'] = wendang['nigaoren']
            liucheng['time'] = nowtime
            liucheng['miaoshu'] = '公文发起'
            liuchenglist.append(liucheng)
            try:
                jieshoudoc = es.get(index='jieshouwendang', doc_type='jieshouwendang', id=userid)
                jieshoudoc = jieshoudoc['_source']
                newdict = {}
                newdict['laiwentime'] = nowtime
                newdict['laiwenren'] = userinfo[userid]['name']
                newdict['doctype'] = wendang['doctype']
                newdict['wancheng'] = 1
                jieshoudoc[wendangid] = newdict
                es.index(index='jieshouwendang', doc_type='jieshouwendang', id=userid, body=jieshoudoc, timeout="1s")
            except:
                newdict = {}
                newdict['laiwentime'] = nowtime
                newdict['laiwenren'] = userinfo[userid]['name']
                newdict['doctype'] = wendang['doctype']
                newdict['wancheng'] = 1
                jieshoudoc = {wendangid: newdict}
                es.index(index='jieshouwendang', doc_type='jieshouwendang', id=userid, body=jieshoudoc, timeout="1s")
        wendang['zhuangtai'] = '审批中'
        if wendang['doctype'] != 'gongwen' and shenpihis[userid]['cishu'] < 2 and userinfo[userid][
            'quanxian'] < 40:
            liucheng = {}
            liucheng['userid'] = userid
            liucheng['name'] = userinfo[userid]['name']
            liucheng['time'] = nowtime
            liucheng['miaoshu'] = '拟办意见'
            wendang['nibanyijian']['name'] = userinfo[userid]['name']
            wendang['nibanyijian']['time'] = nowtime
            liuchenglist.append(liucheng)
            shenpihis[userid]['wancheng'] = 1
            shenpihis[userid]['endtime'] = nowtime
            shenpihis[userid]['caozuo'] = '已完成'
            if userid != wendang['nigaouserid']:
                doc = es.get(index='jieshouwendang', doc_type='jieshouwendang', id=userid)['_source']
                doc[wendangid]['wancheng'] = 1
                es.index(index='jieshouwendang', doc_type='jieshouwendang', id=userid, body=doc, timeout="1s")
        for group in toData:
            for user in group['children']:
                shenpi = {}
                liucheng = {}
                liucheng['userid'] = user['userid']
                liucheng['name'] = user['label']
                liucheng['time'] = nowtime
                liucheng['miaoshu'] = '接收到' + userinfo[userid]['name'] + '的发送'
                liuchenglist.append(liucheng)
                shenpi['name'] = userinfo[user['userid']]['name']
                shenpi['laiwenuserid'] = userid
                shenpi['laiwenren'] = userinfo[userid]['name']
                shenpi['laiwentime'] = nowtime
                shenpi['endtime'] = '-'
                shenpi['wancheng'] = 0
                shenpi['caozuo'] = '未完成'
                shenpi['cishu'] = shenpihis[userid]['cishu'] + 1
                if user['userid'] not in shenpihis or shenpihis[user['userid']]['wancheng'] == 1:
                    shenpihis[user['userid']] = shenpi
                try:
                    jieshoudoc = es.get(index='jieshouwendang', doc_type='jieshouwendang', id=user['userid'])
                    jieshoudoc = jieshoudoc['_source']
                    newdict = {}
                    newdict['laiwentime'] = nowtime
                    newdict['laiwenren'] = userinfo[userid]['name']
                    newdict['doctype'] = wendang['doctype']
                    newdict['wancheng'] = 0
                    jieshoudoc[wendangid] = newdict
                    es.index(index='jieshouwendang', doc_type='jieshouwendang', id=user['userid'], body=jieshoudoc,
                             timeout="1s")
                except:
                    newdict = {}
                    newdict['laiwentime'] = nowtime
                    newdict['laiwenren'] = userinfo[userid]['name']
                    newdict['doctype'] = wendang['doctype']
                    newdict['wancheng'] = 0
                    jieshoudoc = {wendangid: newdict}
                    es.index(index='jieshouwendang', doc_type='jieshouwendang', id=user['userid'], body=jieshoudoc,
                             timeout="1s")
    wendang['shenpihis'] = shenpihis
    wendang['liuchenglist'] = liuchenglist
    es.index(index='wendang', doc_type='wendang', id=wendangid, body=wendang, timeout="1s")
    logger.info("结束")
    return "OK"


@app.route('/api/getfawencaogao', methods=['POST'])
def getfawencaogao():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    doctype = parms['doctype']
    nigaouserid = token_userid[token]
    if doctype == 'shouwen':
        search = {
            "query": {"bool": {"filter": [{"term": {"nigaouserid": nigaouserid}}, {"term": {"doctype": 'shouwen'}},
                                          {"term": {"zhuangtai": "caogao"}}]}}}
    else:
        search = {"query": {
            "bool": {"filter": [{"term": {"nigaouserid": nigaouserid}},
                                {"term": {"zhuangtai": "caogao"}}], "must_not": {"term": {"doctype": 'shouwen'}}}}}
    Docs = es.search(index='wendang', doc_type='wendang', body=search, size=10000)
    Docs = Docs['hits']['hits']
    dataTable = []
    for doc in Docs:
        dataTable.append(doc['_source'])
    logger.info("结束")
    return json.dumps({'dataTable': dataTable})


@app.route('/api/deletefawencaogao', methods=['POST'])
def deletefawencaogao():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    wendangid = parms['wendangid']
    try:
        wendang = es.get(index='wendang', doc_type='wendang', id=wendangid)['_source']
    except:
        wendang = es.get(index='mindoc', doc_type='mindoc', id=wendangid)['_source']
    if (wendang['zhuangtai'] == 'caogao'):
        isExists = os.path.exists('fujian/' + wendangid)
        if isExists:
            for root, dirs, files in os.walk(os.path.join(datapath, 'fujian/' + wendangid)):
                for file in files:
                    try:
                        os.remove(os.path.join(root, file))
                        os.remove(datapathcopy + 'fujian/' + wendangid + '/' + file)
                    except Exception as e:
                        logger.error(e)
            try:
                os.rmdir(datapath + 'fujian/' + wendangid)
                os.rmdir(datapathcopy + 'fujian/' + wendangid)
            except Exception as e:
                logger.error(e)
        try:
            es.delete(index='wendang', doc_type='wendang', id=wendangid)
        except:
            es.delete(index='mindoc', doc_type='mindoc', id=wendangid)
        logger.info("结束")
        return "YES"
    logger.info("结束")
    return "NO"


@app.route('/api/gettongxinlu', methods=['POST'])
def gettongxinlu():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    doc = []
    try:
        doc = es.get(index='changyongzu', doc_type='changyongzu', id=userid)['_source']['changyongzulist']
    except Exception as e:
        logger.error(e)
    if 'isguanliyuan' in parms:
        logger.info("结束")
        return json.dumps({'tongxinlu': usertongxinlu})
    logger.info("结束")
    return json.dumps({'tongxinlu': doc + usertongxinlu})


@app.route('/api/getfawenguanli', methods=['POST'])
def getfawenguanli():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    nigaouserid = token_userid[token]
    doctype = parms['doctype']
    query = parms['query']
    if doctype == 'shouwen':
        search = {
            "query": {
                "bool": {
                    "should": [
                        {"match": {
                            'biaoti': query,
                        }},
                        {"match": {
                            'starttime': query,
                        }},
                        {"match": {
                            'zhuangtai': query,
                        }},
                        {"match": {
                            'endtime': query,
                        }},
                    ],
                    "minimum_should_match": 1,
                    "filter": [{"term": {"nigaouserid": nigaouserid}}, {"term": {"doctype": 'shouwen'}}],
                    "must_not": {"term": {"zhuangtai": "caogao"}}}}}
    else:
        search = {
            "query": {
                "bool": {
                    "should": [{
                        "match": {
                            'biaoti': query,
                        }},
                        {"match": {
                            'starttime': query,
                        }},
                        {"match": {
                            'zhuangtai': query,
                        }},
                        {"match": {
                            'endtime': query,
                        }},
                    ],
                    "minimum_should_match": 1,
                    "filter": [{"term": {"nigaouserid": nigaouserid}}],
                    "must_not": [{"term": {"zhuangtai": "caogao"}}, {"term": {"doctype": "shouwen"}}]}}}
    if query == '':
        search['query']['bool'].pop('should')
        search['query']['bool'].pop('minimum_should_match')
    Docs = es.search(index='wendang', doc_type='wendang', body=search, size=10000)
    Docs = Docs['hits']['hits']
    dataTable = []
    for doc in Docs:
        doc = doc['_source']
        newdoc = {}
        newdoc['wendangid'] = doc['wendangid']
        newdoc['doctype'] = doc['doctype']
        newdoc['biaoti'] = doc['biaoti']
        newdoc['starttime'] = doc['starttime']
        if 'endtime' in doc:
            newdoc['endtime'] = doc['endtime']
        else:
            newdoc['endtime'] = '-'
        newdoc['zhuangtai'] = doc['zhuangtai']
        shenpihis = doc['shenpihis']
        name = ''
        quanxian = 0
        for his in shenpihis:
            shenpi = shenpihis[his]
            if shenpi['wancheng'] == 0 and quanxian < userinfo[his]['quanxian']:
                quanxian = userinfo[his]['quanxian']
                name = userinfo[his]['name']
        if name:
            if quanxian < 50:
                name = name + '[收文拟办]'
            else:
                name = name + '[收文办理]'
        if name == '':
            name = doc['zhuangtai']
        newdoc['liuchenging'] = name
        dataTable.append(newdoc)
    logger.info("结束")
    return json.dumps({'dataTable': dataTable})


@app.route('/api/getdaibanfawen', methods=['POST'])
def getdaibanfawen():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    doctype = parms['doctype']
    query = parms['query']
    try:
        Docs = es.get(index='jieshouwendang', doc_type='jieshouwendang', id=token_userid[token])
        Docs = Docs['_source']
        Docs = sorted(Docs.items(), key=lambda x: x[1]['laiwentime'], reverse=True)
    except:
        Docs = []
    dataTable = []
    for doc in Docs:
        if doc[1]['wancheng'] == 1: continue
        if doctype != 'shouwen' and doc[1]['doctype'] == 'shouwen': continue
        if doctype == 'shouwen' and doc[1]['doctype'] != 'shouwen': continue
        jieshoudoc = es.get(index='wendang', doc_type='wendang', id=doc[0])
        jieshoudoc = jieshoudoc['_source']
        if query not in jieshoudoc['biaoti'] and query not in jieshoudoc['nigaoren'] and query not in jieshoudoc[
            'starttime'] and query not in doc[1]['laiwenren'] and query not in doc[1]['laiwentime'] and query not in \
                jieshoudoc[
                    'zhuangtai']: continue
        newdoc = {}
        newdoc['wendangid'] = jieshoudoc['wendangid']
        newdoc['doctype'] = jieshoudoc['doctype']
        newdoc['biaoti'] = jieshoudoc['biaoti']
        newdoc['fawenren'] = jieshoudoc['nigaoren']
        newdoc['starttime'] = jieshoudoc['starttime']
        newdoc['laiwenren'] = doc[1]['laiwenren']
        newdoc['laiwentime'] = doc[1]['laiwentime']
        if 'endtime' in jieshoudoc:
            newdoc['endtime'] = jieshoudoc['endtime']
        else:
            newdoc['endtime'] = '-'
        newdoc['zhuangtai'] = jieshoudoc['zhuangtai']
        shenpihis = jieshoudoc['shenpihis']
        name = ''
        quanxian = 0
        cishu = 10
        for his in shenpihis:
            shenpi = shenpihis[his]
            if shenpi['wancheng'] == 0:
                if cishu > shenpi['cishu']:
                    cishu = shenpi['cishu']
                    quanxian = userinfo[his]['quanxian']
                if cishu == shenpi['cishu'] and quanxian < userinfo[his]['quanxian']:
                    quanxian = userinfo[his]['quanxian']
                    name = userinfo[his]['name']
        if cishu == 2 and shenpihis[userid]['cishu'] == cishu and userinfo[userid]['quanxian'] < quanxian - 5 and \
                jieshoudoc[
                    'doctype'] != 'gongwen' and jieshoudoc['doctype'] != 'shouwen':
            continue
        if name:
            if quanxian < 25:
                name = name + '[收文审批]'
            elif quanxian < 50:
                name = name + '[收文拟办]'
            else:
                name = name + '[收文办理]'
        if name == '':
            name = jieshoudoc['zhuangtai']
        newdoc['liuchenging'] = name
        dataTable.append(newdoc)
    logger.info("结束")
    return json.dumps({'dataTable': dataTable})


@app.route('/api/getshouwenguanli', methods=['POST'])
def getshouwenguanli():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    doctype = parms['doctype']
    query = parms['query']
    try:
        Docs = es.get(index='jieshouwendang', doc_type='jieshouwendang', id=userid)
        Docs = Docs['_source']
        Docs = sorted(Docs.items(), key=lambda x: x[1]['laiwentime'], reverse=True)
    except:
        Docs = []
    dataTable = []
    for doc in Docs:
        if doc[1]['wancheng'] == 0: continue
        if doctype != 'shouwen' and doc[1]['doctype'] == 'shouwen': continue
        if doctype == 'shouwen' and doc[1]['doctype'] != 'shouwen': continue
        jieshoudoc = es.get(index='wendang', doc_type='wendang', id=doc[0])
        jieshoudoc = jieshoudoc['_source']
        if query not in jieshoudoc['biaoti'] and query not in jieshoudoc['nigaoren'] and query not in jieshoudoc[
            'starttime'] and query not in doc[1]['laiwenren'] and query not in doc[1]['laiwentime'] and query not in \
                jieshoudoc[
                    'zhuangtai']: continue
        newdoc = {}
        newdoc['wendangid'] = jieshoudoc['wendangid']
        newdoc['doctype'] = jieshoudoc['doctype']
        newdoc['biaoti'] = jieshoudoc['biaoti']
        newdoc['fawenren'] = jieshoudoc['nigaoren']
        newdoc['starttime'] = jieshoudoc['starttime']
        newdoc['laiwenren'] = doc[1]['laiwenren']
        newdoc['laiwentime'] = doc[1]['laiwentime']
        if 'endtime' in jieshoudoc:
            newdoc['endtime'] = jieshoudoc['endtime']
        else:
            newdoc['endtime'] = '-'
        newdoc['zhuangtai'] = jieshoudoc['zhuangtai']
        shenpihis = jieshoudoc['shenpihis']
        name = ''
        quanxian = 0
        for his in shenpihis:
            shenpi = shenpihis[his]
            if shenpi['wancheng'] == 0 and quanxian < userinfo[his]['quanxian']:
                quanxian = userinfo[his]['quanxian']
                name = userinfo[his]['name']
        if name:
            if quanxian < 25:
                name = name + '[收文审批]'
            elif quanxian < 50:
                name = name + '[收文拟办]'
            else:
                name = name + '[收文办理]'
        if name == '':
            name = jieshoudoc['zhuangtai']
        newdoc['liuchenging'] = name
        dataTable.append(newdoc)
    logger.info("结束")
    return json.dumps({'dataTable': dataTable})


@app.route('/api/getwendangid', methods=['POST'])
def getwendangid():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    wendangid = parms['wendangid']
    doc = es.get(index='wendang', doc_type='wendang', id=wendangid)
    doc = doc['_source']
    xiugai = 0
    hegao = 0
    tuiwen = 0
    pishi = 0
    yuedu = 0
    if doc['zhuangtai'] == 'caogao':
        xiugai = 1
        if userinfo[userid]['quanxian'] < 40:
            hegao = 1
    elif doc['zhuangtai'] != '退文' and doc['zhuangtai'] != '已完成':
        shenpi = doc['shenpihis'][userid]
        if shenpi['wancheng'] == 0:
            if doc['doctype'] != 'shouwen':
                if userinfo[userid]['quanxian'] == 10 and shenpi['cishu'] == 3:
                    tuiwen = 1
                    pishi = 1
                if userinfo[userid]['quanxian'] < 40 and shenpi['cishu'] < 3:
                    tuiwen = 1
                    if userinfo[userid]['quanxian'] < 20:
                        pishi = 1
                    elif userinfo[userid]['quanxian'] < 24:
                        pishi = 2
                    else:
                        pishi = 3
                    if userinfo[userid]['quanxian'] == 29:
                        pishi = 4
                    if shenpi['cishu'] == 1:
                        hegao = 1
                        pishi = 0
            else:
                if userinfo[userid]['quanxian'] <= 20:
                    tuiwen = 1
                    pishi = 1
                if userinfo[userid]['quanxian'] < 40 and shenpi['cishu'] == 1:
                    tuiwen = 1
                    hegao = 1
                    pishi = 0
    if userid in doc['shenpihis'] and doc['shenpihis'][userid]['wancheng'] == 0:
        if xiugai + hegao + tuiwen + pishi == 0:
            yuedu = 1
        if doc['doctype'] == 'gongwen':
            yuedu = 1
    logger.info(xiugai, hegao, tuiwen, pishi, yuedu)
    logger.info("结束")
    return json.dumps(
        {'xiugai': xiugai, 'hegao': hegao, 'tuiwen': tuiwen, 'pishi': pishi, 'yuedu': yuedu, 'data': doc})


@app.route('/api/tuiwen', methods=['POST'])
def tuiwen():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    nibanyijian = parms['nibanyijian']
    wendangid = parms['wendangid']
    pishi = int(parms['pishi'])
    doc = es.get(index='wendang', doc_type='wendang', id=wendangid)
    doc = doc['_source']
    doc['zhuangtai'] = '退文'
    doc['nibanyijian'] = nibanyijian
    nowtime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    liucheng = {}
    liucheng['userid'] = userid
    liucheng['name'] = userinfo[userid]['name']
    liucheng['time'] = nowtime
    liucheng['miaoshu'] = '退文'
    doc['liuchenglist'].append(liucheng)
    if pishi > 0:
        qianming = {}
        qianming['time'] = nowtime
        qianming['yijian'] = parms['lingdaopishi']
        qianming['userid'] = userid
        qianming['name'] = userinfo[userid]['name']
        if doc['doctype'] == 'gouzhi':
            cailiao = parms['cailiao']
            caiwu = parms['caiwu']
            if len(caiwu):
                qianming['leixing'] = 1
                qianming['yijian'] = caiwu
            else:
                qianming['leixing'] = 0
                qianming['yijian'] = cailiao
        if userinfo[userid]['quanxian'] <= 20:
            try:
                qianming['imageurl'] = userinfo[userid]['qianmingUrl']
            except:
                qianming['imageurl'] = ""
        if doc['doctype'] == 'shouwen':
            doc['lingdaopishilist'].append(qianming)
        else:
            if pishi == 1:
                doc['biglingdaolist'].append(qianming)
            elif pishi == 2:
                doc['midlingdaolist'].append(qianming)
            elif pishi == 3:
                doc['minlingdaolist'].append(qianming)
            else:
                doc['falvlingdaolist'].append(qianming)
    for newuser in doc['shenpihis']:
        doc['shenpihis'][newuser]['endtime'] = nowtime
        doc['shenpihis'][newuser]['wancheng'] = 1
        doc['shenpihis'][newuser]['caozuo'] = '已完成'
        newdoc = es.get(index='jieshouwendang', doc_type='jieshouwendang', id=userid)['_source']
        newdoc[wendangid]['wancheng'] = 1
        es.index(index='jieshouwendang', doc_type='jieshouwendang', id=userid, body=newdoc)
    try:
        jieshoudoc = es.get(index='jieshouwendang', doc_type='jieshouwendang', id=doc['nigaouserid'])['_source']
        newdict = {}
        newdict['laiwentime'] = nowtime
        newdict['laiwenren'] = userinfo[userid]['name']
        newdict['doctype'] = doc['doctype']
        newdict['wancheng'] = 0
        jieshoudoc[wendangid] = newdict
        es.index(index='jieshouwendang', doc_type='jieshouwendang', id=doc['nigaouserid'], body=jieshoudoc)
    except:
        newdict = {}
        newdict['laiwentime'] = nowtime
        newdict['laiwenren'] = userinfo[userid]['name']
        newdict['doctype'] = doc['doctype']
        newdict['wancheng'] = 0
        jieshoudoc = {wendangid: newdict}
        es.index(index='jieshouwendang', doc_type='jieshouwendang', id=doc['nigaouserid'], body=jieshoudoc)
    doc['shenpihis'][doc['nigaouserid']]['wancheng'] = 0
    doc['shenpihis'][doc['nigaouserid']]['caozuo'] = '未完成'
    es.index(index='wendang', doc_type='wendang', id=wendangid, body=doc)
    logger.info("结束")
    return "OK"


@app.route('/api/pishi', methods=['POST'])
def pishi():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    wendangid = parms['wendangid']
    pishi = int(parms['pishi'])
    nowtime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    doc = es.get(index='jieshouwendang', doc_type='jieshouwendang', id=userid)['_source']
    doc[wendangid]['wancheng'] = 1
    es.index(index='jieshouwendang', doc_type='jieshouwendang', id=userid, body=doc)
    doc = es.get(index='wendang', doc_type='wendang', id=wendangid)['_source']
    doc['shenpihis'][userid]['wancheng'] = 1
    doc['shenpihis'][userid]['endtime'] = nowtime
    doc['shenpihis'][userid]['caozuo'] = '已完成'
    liucheng = {}
    liucheng['userid'] = userid
    liucheng['name'] = userinfo[userid]['name']
    liucheng['time'] = nowtime
    qianming = {}
    qianming['time'] = nowtime
    qianming['yijian'] = parms['lingdaopishi']
    qianming['userid'] = userid
    qianming['name'] = userinfo[userid]['name']
    if doc['doctype'] == 'gouzhi':
        cailiao = parms['cailiao']
        caiwu = parms['caiwu']
        if len(caiwu):
            qianming['leixing'] = 1
            qianming['yijian'] = caiwu
        else:
            qianming['leixing'] = 0
            qianming['yijian'] = cailiao
    if userinfo[userid]['quanxian'] <= 20:
        try:
            qianming['imageurl'] = userinfo[userid]['qianmingUrl']
        except:
            qianming['imageurl'] = ""
    if doc['doctype'] == 'shouwen':
        liucheng['miaoshu'] = '审批完成'
        doc['lingdaopishilist'].append(qianming)
    else:
        if pishi == 1:
            doc['biglingdaolist'].append(qianming)
            liucheng['miaoshu'] = '签发完成'
        elif pishi == 2:
            doc['midlingdaolist'].append(qianming)
            liucheng['miaoshu'] = '签阅完成'
        elif pishi == 3:
            doc['minlingdaolist'].append(qianming)
            liucheng['miaoshu'] = '会阅完成'
        else:
            doc['falvlingdaolist'].append(qianming)
            liucheng['miaoshu'] = '合法性审查完成'
    doc['liuchenglist'].append(liucheng)
    flag = 1
    for his in doc['shenpihis']:
        shenpi = doc['shenpihis'][his]
        if shenpi['wancheng'] == 0:
            flag = 0
            break
    if flag == 1:
        liucheng = {}
        liucheng['userid'] = userid
        liucheng['name'] = userinfo[userid]['name']
        liucheng['time'] = nowtime
        liucheng['miaoshu'] = '流程已完成'
        doc['liuchenglist'].append(liucheng)
        doc['zhuangtai'] = '已完成'
        doc['endtime'] = nowtime
    es.index(index='wendang', doc_type='wendang', id=wendangid, body=doc)
    if doc['doctype'] != 'shouwen':
        logger.info("结束")
        return json.dumps({'biglingdaolist': doc['biglingdaolist'], 'midlingdaolist': doc['midlingdaolist'],
                           'minlingdaolist': doc['minlingdaolist'], 'falvlingdaolist': doc['falvlingdaolist']})
    else:
        logger.info("结束")
        return json.dumps({'lingdaopishilist': doc['lingdaopishilist']})


@app.route('/api/yiyue', methods=['POST'])
def yiyue():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    wendangid = parms['wendangid']
    banli = parms['banli']
    nowtime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    doc = es.get(index='jieshouwendang', doc_type='jieshouwendang', id=userid)['_source']
    if doc[wendangid]['wancheng'] == 1:
        if doc['doctype'] != 'gongwen':
            logger.info("结束")
            return "OK"
        else:
            logger.info("结束")
            return json.dumps({'qianyuelist': doc['qianyuelist']})
    doc[wendangid]['wancheng'] = 1
    es.index(index='jieshouwendang', doc_type='jieshouwendang', id=userid, body=doc)
    doc = es.get(index='wendang', doc_type='wendang', id=wendangid)['_source']
    doc['shenpihis'][userid]['wancheng'] = 1
    doc['shenpihis'][userid]['endtime'] = nowtime
    doc['shenpihis'][userid]['caozuo'] = '已完成'
    liucheng = {}
    liucheng['userid'] = userid
    liucheng['name'] = userinfo[userid]['name']
    liucheng['time'] = nowtime
    wenjianbanli = {}
    wenjianbanli['name'] = userinfo[userid]['name']
    wenjianbanli['time'] = nowtime
    wenjianbanli['yijian'] = banli
    doc['qianyuelist'].append(wenjianbanli)
    if doc['doctype'] == 'gongwen':
        liucheng['miaoshu'] = '已阅'
    else:
        if doc['zhuangtai'] != '退文':
            liucheng['miaoshu'] = '已办理'
        else:
            liucheng['miaoshu'] = '已退文办理'
    doc['liuchenglist'].append(liucheng)
    doc['shenpihis'][userid]['wancheng'] = 1
    if doc['zhuangtai'] != '退文':
        flag = 1
        for his in doc['shenpihis']:
            shenpi = doc['shenpihis'][his]
            if shenpi['wancheng'] == 0:
                flag = 0
                break
        if flag == 1:
            liucheng = {}
            liucheng['userid'] = userid
            liucheng['name'] = userinfo[userid]['name']
            liucheng['time'] = nowtime
            liucheng['miaoshu'] = '流程已完成'
            doc['liuchenglist'].append(liucheng)
            doc['zhuangtai'] = '已完成'
            doc['endtime'] = nowtime
    es.index(index='wendang', doc_type='wendang', id=wendangid, body=doc)
    logger.info("结束")
    return json.dumps({'qianyuelist': doc['qianyuelist']})


@app.route('/api/baocunimage', methods=['POST'])
def baocunimage():
    logger.info("开始")
    wendangid = time.strftime("%Y%m%d%H%M%S", time.localtime())
    suiji = str(random.randint(10000000000000, 99999999999999))
    filename = 'editor/' + wendangid + suiji + '.jpg'
    f = open(datapath + filename, 'wb')
    imagedata = request.stream.read()
    f.write(imagedata)
    f.close()
    f = open(datapathcopy + filename, 'wb')
    f.write(imagedata)
    f.close()
    logger.info("结束")
    return json.dumps({'url': filename})


@app.route('/api/fasongmindoc', methods=['POST'])
def fasongmindoc():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    wendang = parms['wendang']
    if len(wendang['biaoti']) == 0:
        wendang['biaoti'] = '空'
    wendangid = wendang['wendangid']
    if 'toData' in parms:
        toData = parms['toData']
    else:
        toData = []
    nowtime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    if 'starttime' not in wendang or wendang['starttime'] == '':
        wendang['starttime'] = nowtime
        isExists = os.path.exists('fujian/' + wendangid)
        if isExists:
            for root, dirs, files in os.walk(os.path.join(datapath, 'fujian/' + wendangid)):
                for file in files:
                    flag = 1
                    for fujian in wendang['fileList']:
                        if fujian['name'] == file:
                            flag = 0
                    if flag:
                        try:
                            os.remove(os.path.join(root, file))
                            os.remove(datapathcopy + 'fujian/' + wendangid + '/' + file)
                        except Exception as e:
                            logger.error(e)
    if len(toData):
        if wendang['doctype'] == 'youjian':
            wendang['zhuangtai'] = 'wancheng'
        flag = 1
        for group in toData:
            for user in group['children']:
                if wendang['doctype'] == 'duban' or wendang['doctype'] == 'youjian':
                    shenpi = {}
                    shenpi['name'] = userinfo[user['userid']]['name']
                    shenpi['caozuo'] = "未完成"
                    wendang['shenpihis'][user['userid']] = shenpi
                if wendang['doctype'] == 'huiyifaqi':
                    wendang['userlist'].append({'name': userinfo[user['userid']]['name']})
                if user['userid'] == userid:
                    flag = 0
                try:
                    jieshoudoc = es.get(index='jieshoumindoc', doc_type='jieshoumindoc', id=user['userid'])
                    jieshoudoc = jieshoudoc['_source']
                    newdict = {}
                    newdict['biaoti'] = wendang['biaoti']
                    newdict['starttime'] = nowtime
                    newdict['nigaoren'] = wendang['nigaoren']
                    newdict['doctype'] = wendang['doctype']
                    newdict['zhuangtai'] = '未完成'
                    jieshoudoc[wendangid] = newdict
                    es.index(index='jieshoumindoc', doc_type='jieshoumindoc', id=user['userid'], body=jieshoudoc)
                except:
                    newdict = {}
                    newdict['biaoti'] = wendang['biaoti']
                    newdict['starttime'] = nowtime
                    newdict['nigaoren'] = wendang['nigaoren']
                    newdict['doctype'] = wendang['doctype']
                    newdict['zhuangtai'] = '未完成'
                    jieshoudoc = {wendangid: newdict}
                    es.index(index='jieshoumindoc', doc_type='jieshoumindoc', id=user['userid'], body=jieshoudoc)
        if (wendang['doctype'] == 'huiyifaqi' or wendang['doctype'] == 'duban') and flag:
            if wendang['doctype'] == 'huiyifaqi':
                wendang['userlist'].append({'name': userinfo[userid]['name']})
            try:
                jieshoudoc = es.get(index='jieshoumindoc', doc_type='jieshoumindoc', id=userid)
                jieshoudoc = jieshoudoc['_source']
                newdict = {}
                newdict['biaoti'] = wendang['biaoti']
                newdict['starttime'] = nowtime
                newdict['nigaoren'] = wendang['nigaoren']
                newdict['doctype'] = wendang['doctype']
                jieshoudoc[wendangid] = newdict
                es.index(index='jieshoumindoc', doc_type='jieshoumindoc', id=userid, body=jieshoudoc)
            except:
                newdict = {}
                newdict['biaoti'] = wendang['biaoti']
                newdict['starttime'] = nowtime
                newdict['nigaoren'] = wendang['nigaoren']
                newdict['doctype'] = wendang['doctype']
                jieshoudoc = {wendangid: newdict}
                es.index(index='jieshoumindoc', doc_type='jieshoumindoc', id=userid, body=jieshoudoc)
    es.index(index='mindoc', doc_type='mindoc', id=wendangid, body=wendang)
    logger.info("结束")
    return "OK"


@app.route('/api/getmindoccaogao', methods=['POST'])
def getmindoccaogao():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    doctype = parms['doctype']
    nigaouserid = token_userid[token]
    search = {"query": {"bool": {"filter": [{"term": {"nigaouserid": nigaouserid}}, {"term": {"doctype": doctype}},
                                            {"term": {"zhuangtai": "caogao"}}]}}}
    Docs = es.search(index='mindoc', doc_type='mindoc', body=search, size=10000)
    Docs = Docs['hits']['hits']
    dataTable = []
    for doc in Docs:
        dataTable.append(doc['_source'])
    logger.info("结束")
    return json.dumps({'dataTable': dataTable})


@app.route('/api/deletemindoccaogao', methods=['POST'])
def deletemindoccaogao():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    wendangid = parms['wendangid']
    wendang = es.get(index='mindoc', doc_type='mindoc', id=wendangid)['_source']
    if (wendang['zhuangtai'] == 'caogao'):
        es.delete(index='wendang', doc_type='wendang', id=wendangid)
        logger.info("结束")
        return "YES"
    logger.info("结束")
    return "NO"


@app.route('/api/getmindocid', methods=['POST'])
def getmindocid():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    wendangid = parms['wendangid']
    doc = es.get(index='mindoc', doc_type='mindoc', id=wendangid)
    doc = doc['_source']
    xiugai = 0
    yuedu = 0
    if 'shenpihis' in doc and userid in doc['shenpihis'] and doc['shenpihis'][userid]['caozuo'] == '未完成':
        yuedu = 1
    logger.info("结束")
    return json.dumps(
        {'xiugai': xiugai, 'yuedu': yuedu, 'data': doc})


@app.route('/api/getfasongguanli', methods=['POST'])
def getfasongguanli():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    doctype = parms['doctype']
    query = parms['query']
    search = {
        "query": {
            "bool": {
                "should": [
                    {"match": {
                        'biaoti': query,
                    }},
                    {"match": {
                        'starttime': query,
                    }},
                ],
                "minimum_should_match": 1,
                "filter": [{"term": {"nigaouserid": userid}},
                           {"term": {"doctype": doctype}}]}}}
    if doctype == 'youjian':
        search['query']['bool']['filter'].append({"term": {"zhuangtai": "wancheng"}}, )
    elif doctype == 'tixing':
        search['query']['bool']['filter'] = [{"term": {"doctype": doctype}}]
        search['query']['bool']['should'].append({"match": {'nigaoren': query, }})
        search['query']['bool']['should'].append({"match": {'jinji': query, }})
        search['query']['bool']['should'].append({"match": {'zhuangtai': query, }})
        search['query']['bool']['should'].append({"match": {'wanchengren': query, }})
        search['query']['bool']['should'].append({"match": {'wanchengtime': query, }})
        search['query']['bool']['should'].append({"match": {'starttime': query, }})
        search['query']['bool']['should'].append({"match": {'endtime': query, }})
    if query == '':
        search['query']['bool'].pop('should')
        search['query']['bool'].pop('minimum_should_match')
    Docs = es.search(index='mindoc', doc_type='mindoc', body=search, size=10000)
    Docs = Docs['hits']['hits']
    dataTable = []
    for doc in Docs:
        doc = doc['_source']
        if doc['doctype'] == 'tixing':
            if doc['zhuangtai'] == '未处理':
                if time.strftime("%Y-%m-%d", time.localtime()) < doc['kaishitime']:
                    doc['zhuangtai'] = '提醒未开始'
                elif time.strftime("%Y-%m-%d", time.localtime()) <= doc['jieshutime']:
                    timeStamp = int(time.mktime(time.strptime(doc['kaishitime'], "%Y-%m-%d")))
                    jiange = int(doc['jiange'])
                    if (int(time.mktime(
                            time.strptime(time.strftime("%Y-%m-%d", time.localtime()), "%Y-%m-%d"))) - timeStamp) % (
                            jiange * 86400) == 0:
                        doc['zhuangtai'] = '正在提醒'
                    else:
                        doc['zhuangtai'] = '待唤醒中'
                if time.strftime("%Y-%m-%d", time.localtime()) > doc['jieshutime']:
                    doc['zhuangtai'] = '提醒已过期'
            dataTable.append(doc)
        if doc['doctype'] == 'youjian':
            newdoc = {}
            newdoc['wendangid'] = doc['wendangid']
            newdoc['biaoti'] = doc['biaoti']
            newdoc['starttime'] = doc['starttime']
            dataTable.append(newdoc)
    logger.info("结束")
    return json.dumps({'dataTable': dataTable})


@app.route('/api/getgonggaoguanli', methods=['POST'])
def getgonggaoguanli():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    doctype = parms['doctype']
    query = parms['query']
    search = {
        "query": {
            "bool": {
                "should": [
                    {"match": {
                        'biaoti': query,
                    }},
                    {"match": {
                        'nigaoren': query,
                    }},
                    {"match": {
                        'starttime': query,
                    }},
                ],
                "minimum_should_match": 1,
                "filter": [{"term": {"doctype": doctype}}]}}}
    if query == '':
        search['query']['bool'].pop('should')
        search['query']['bool'].pop('minimum_should_match')
    Docs = es.search(index='mindoc', doc_type='mindoc', body=search, size=10000)
    Docs = Docs['hits']['hits']
    dataTable = []
    for doc in Docs:
        doc = doc['_source']
        newdoc = {}
        newdoc['wendangid'] = doc['wendangid']
        newdoc['biaoti'] = doc['biaoti']
        newdoc['nigaoren'] = doc['nigaoren']
        newdoc['starttime'] = doc['starttime']
        dataTable.append(newdoc)
    logger.info("结束")
    return json.dumps({'dataTable': dataTable})


@app.route('/api/getjieshouguanli', methods=['POST'])
def getjieshouguanli():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    doctype = parms['doctype']
    query = parms['query']
    try:
        Docs = es.get(index='jieshoumindoc', doc_type='jieshoumindoc', id=userid)
        Docs = Docs['_source']
        Docs = sorted(Docs.items(), key=lambda x: x[1]['starttime'], reverse=True)
    except:
        Docs = []
    dataTable = []
    nowtime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    for doc in Docs:
        jieshoudoc = es.get(index='mindoc', doc_type='mindoc', id=doc[0])
        jieshoudoc = jieshoudoc['_source']
        if doctype != jieshoudoc['doctype']: continue
        if doctype == 'youjian' and query not in jieshoudoc['biaoti'] and query not in jieshoudoc[
            'nigaoren'] and query not in jieshoudoc[
            'starttime']: continue
        if doctype == 'huiyifaqi' and query not in jieshoudoc['biaoti'] and query not in jieshoudoc[
            'nigaoren'] and query not in jieshoudoc[
            'kaishitime'] and query not in jieshoudoc['riqi']:
            continue
        if doctype == 'duban' and query not in jieshoudoc['biaoti'] and query not in jieshoudoc[
            'nigaoren'] and query not in jieshoudoc[
            'starttime'] and query not in jieshoudoc['jinji'] and query not in jieshoudoc['zhuangtai']:
            continue
        if doctype == 'youjian':
            newdoc = {}
            newdoc['wendangid'] = jieshoudoc['wendangid']
            newdoc['biaoti'] = jieshoudoc['biaoti']
            newdoc['nigaoren'] = jieshoudoc['nigaoren']
            newdoc['starttime'] = jieshoudoc['starttime']
            dataTable.append(newdoc)
        else:
            if doctype == 'huiyifaqi':
                if jieshoudoc['riqi'] + ' ' + jieshoudoc['kaishitime'] > nowtime:
                    jieshoudoc['zhuangtai'] = '未开始'
                elif jieshoudoc['riqi'] + ' ' + jieshoudoc['jieshutime'] < nowtime:
                    jieshoudoc['zhuangtai'] = '已结束'
                else:
                    jieshoudoc['zhuangtai'] = '进行中'
            dataTable.append(jieshoudoc)
    logger.info("结束")
    return json.dumps({'dataTable': dataTable})


@app.route('/api/wanchengmindoc', methods=['POST'])
def wanchengmindoc():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    wendangid = parms['wendangid']
    token = parms['token']
    userid = token_userid[token]
    doc = es.get(index='mindoc', doc_type='mindoc', id=wendangid)
    doc = doc['_source']
    doc['zhuangtai'] = '处理完成'
    doc['wanchengid'] = userid
    doc['wanchengren'] = userinfo[userid]['name']
    nowtime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    doc['wanchengtime'] = nowtime
    es.index(index='mindoc', doc_type='mindoc', id=wendangid, body=doc)
    logger.info("结束")
    return "OK"


@app.route('/api/mindocyiyue', methods=['POST'])
def mindocyiyue():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    wendangid = parms['wendangid']
    nowtime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    doc = es.get(index='mindoc', doc_type='mindoc', id=wendangid)['_source']
    doc['shenpihis'][userid]['caozuo'] = '已完成'
    doc['shenpihis'][userid]['endtime'] = nowtime
    flag = 1
    for shenpi in doc['shenpihis']:
        shenpi = doc['shenpihis'][shenpi]
        if shenpi['caozuo'] == '未完成':
            flag = 0
            break
    if flag:
        doc['endtime'] = nowtime
        doc['zhuangtai'] = "已完成"
    if 'banli' in parms:
        banli = parms['banli']
        wenjianbanli = {}
        wenjianbanli['name'] = userinfo[userid]['name']
        wenjianbanli['time'] = nowtime
        wenjianbanli['yijian'] = banli
        doc['qianyuelist'].append(wenjianbanli)
    es.index(index='mindoc', doc_type='mindoc', id=wendangid, body=doc)
    logger.info("结束")
    if doc['doctype'] == 'duban':
        return json.dumps({'qianyuelist': doc['qianyuelist']})
    return "OK"


@app.route('/api/getusers', methods=['POST'])
def getusers():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    query = parms['query']
    dataTable = []
    for user in userinfo:
        if query not in userinfo[user]['name'] and query not in userinfo[user]['group'] and query not in userinfo[user][
            'zhiweiname'] and query not in userinfo[user]['phone'] and query not in userinfo[user][
            'dianhua'] and query not in \
                userinfo[user]['email']: continue
        dataTable.append(userinfo[user])
    logger.info("结束")
    return json.dumps({'dataTable': dataTable})


@app.route('/api/getshouyeweidu', methods=['POST'])
def getshouyeweidu():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    duban, huiyifaqi, youjian, tixing, fawenduban, shouwenduban = 0, 0, 0, 0, 0, 0
    try:
        Docs = es.get(index='jieshoumindoc', doc_type='jieshoumindoc', id=userid)
        Docs = Docs['_source']
        Docs = sorted(Docs.items(), key=lambda x: x[1]['starttime'], reverse=True)
    except:
        Docs = []
    nowtime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    for doc in Docs:
        jieshoudoc = es.get(index='mindoc', doc_type='mindoc', id=doc[0])
        jieshoudoc = jieshoudoc['_source']
        if jieshoudoc['doctype'] == 'duban':
            if userid in jieshoudoc['shenpihis'] and jieshoudoc['shenpihis'][userid]['caozuo'] == '未完成':
                duban += 1
        if jieshoudoc['doctype'] == 'huiyifaqi':
            if jieshoudoc['riqi'] + ' ' + jieshoudoc['jieshutime'] > nowtime:
                huiyifaqi += 1
        if jieshoudoc['doctype'] == 'youjian':
            if jieshoudoc['shenpihis'][userid]['caozuo'] == '未完成':
                youjian += 1
    search = {"query": {"bool": {"filter": [{"term": {"doctype": 'tixing'}}]}}}
    Docs = es.search(index='mindoc', doc_type='mindoc', body=search, size=10000)
    Docs = Docs['hits']['hits']
    nowtime = time.strftime("%Y-%m-%d", time.localtime())
    for doc in Docs:
        doc = doc['_source']
        if doc['zhuangtai'] == '未处理' and nowtime >= doc['kaishitime'] and nowtime <= doc['jieshutime']:

            timeStamp = int(time.mktime(time.strptime(doc['kaishitime'], "%Y-%m-%d")))
            jiange = int(doc['jiange'])
            yushu = (int(time.mktime(
                time.strptime(time.strftime("%Y-%m-%d", time.localtime()), "%Y-%m-%d"))) - timeStamp) % (
                            jiange * 86400) == 0
            if yushu:
                tixing += 1
    try:
        Docs = es.get(index='jieshouwendang', doc_type='jieshouwendang', id=userid)
        Docs = Docs['_source']
        Docs = sorted(Docs.items(), key=lambda x: x[1]['starttime'], reverse=True)
    except:
        Docs = []
    for doc in Docs:
        jieshoudoc = es.get(index='wendang', doc_type='wendang', id=doc[0])
        jieshoudoc = jieshoudoc['_source']
        if jieshoudoc['doctype'] != 'shouwen' and jieshoudoc['zhuangtai'] == '审批中':
            for shenpi in jieshoudoc['shenpihis']:
                if shenpi['wancheng'] == 0 and int(
                        time.mktime(time.strftime("%Y-%m-%d %H:%M:%S", shenpi['laiwentime']))) < int(
                    time.time()) - 259200:
                    fawenduban += 1
                    break
        if jieshoudoc['doctype'] == 'shouwen' and jieshoudoc['zhuangtai'] == '审批中':
            for shenpi in jieshoudoc['shenpihis']:
                if shenpi['wancheng'] == 0 and int(
                        time.mktime(time.strftime("%Y-%m-%d %H:%M:%S", shenpi['laiwentime']))) < int(
                    time.time()) - 259200:
                    shouwenduban += 1
                    break
    logger.info("结束")
    return json.dumps(
        {'duban': duban, 'huiyifaqi': huiyifaqi, 'youjian': youjian, 'tixing': tixing, 'fawenduban': fawenduban,
         'shouwenduban': shouwenduban})


@app.route('/api/xinjianwenjianjia', methods=['POST'])
def xinjianwenjianjia():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    selectedOptions = parms['selectedOptions']
    value = parms['value']
    options = []
    try:
        options = es.get(index='bumenwenjian', doc_type='bumenwenjian', id='bumenwenjian')['_source']['options']
    except:
        logger.info("部门文件没有建")
        None
    newoptions = options
    for wenjianjia in selectedOptions:
        for option in newoptions:
            if option['value'] == wenjianjia:
                newoptions = option['children']
                break
    bianhao = time.strftime("%Y%m%d%H%M%S", time.localtime()) + str(random.randint(10000000000000, 99999999999999))
    newoptions.append(
        {'value': value, 'label': value, 'bianhao': bianhao, 'type': '', 'select': 0, 'children': [], 'userid': userid})
    es.index(index='bumenwenjian', doc_type='bumenwenjian', id='bumenwenjian', body={'options': options})
    logger.info("结束")
    return json.dumps({'options': options, 'userid': userid, 'bianhao': bianhao})


@app.route('/api/huoqubumenwenjian', methods=['POST'])
def huoqubumenwenjian():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    options = []
    try:
        options = es.get(index='bumenwenjian', doc_type='bumenwenjian', id='bumenwenjian')['_source']['options']
    except:
        logger.info("部门文件没有建")
        None
    logger.info("结束")
    return json.dumps({'options': options})


@app.route('/api/baocunwenjian', methods=['POST'])
def baocunwenjian():
    logger.info("开始")
    global quanjusuo
    upload_file = request.files['file']
    token = request.form.get('token')
    userid = token_userid[token]
    selectedOptions = json.loads(request.form.get('selectedOptions'))
    options = []
    while quanjusuo > 0 and quanjusuo < 600:
        quanjusuo += 1
        time.sleep(0.5)
    quanjusuo = 1
    try:
        options = es.get(index='bumenwenjian', doc_type='bumenwenjian', id='bumenwenjian')['_source']['options']
    except:
        logger.info("部门文件没有建")
        None
    newoptions = options
    for wenjianjia in selectedOptions:
        for option in newoptions:
            if option['label'] == wenjianjia:
                newoptions = option['children']
                break
    for option in newoptions:
        if option['type'] != '' and option['label'] == upload_file.filename:
            logger.info("结束")
            return json.dumps({'MSG': 'NO', 'label': upload_file.filename})
    bianhao = time.strftime("%Y%m%d%H%M%S", time.localtime()) + str(random.randint(10000000000000, 99999999999999))
    isExists = os.path.exists(datapath + 'bumenwenjian/' + bianhao)
    if not isExists:
        os.makedirs('bumenwenjian/' + bianhao)
        os.makedirs(datapathcopy + 'bumenwenjian/' + bianhao)
    name = 'bumenwenjian/' + bianhao + '/' + upload_file.filename
    upload_file.save(datapath + name)
    open(datapathcopy + name, "wb").write(open(name, "rb").read())
    newoptions.append(
        {'value': upload_file.filename, 'label': upload_file.filename, 'bianhao': bianhao, 'type': 'wenjian',
         'select': 0, 'children': [],
         'userid': userid})
    es.index(index='bumenwenjian', doc_type='bumenwenjian', id='bumenwenjian', body={'options': options})
    quanjusuo = 0
    logger.info("结束")
    return json.dumps({'MSG': 'YES', 'options': options,
                       'files': newoptions})


def deletewenjianjia(options):
    logger.info("开始")
    if 'children' in options:
        for option in options['children']:
            if option['type'] == '':
                deletewenjianjia(option)
            else:
                isExists = os.path.exists(datapath + 'bumenwenjian/' + option['bianhao'])
                if isExists:
                    for root, dirs, files in os.walk(os.path.join(datapath, 'bumenwenjian/' + option['bianhao'])):
                        for file in files:
                            try:
                                os.remove(os.path.join(root, file))
                                os.remove(datapathcopy + 'bumenwenjian/' + option['bianhao'] + '/' + file)
                            except Exception as e:
                                logger.error(e)
                    try:
                        os.rmdir(datapath + 'bumenwenjian/' + option['bianhao'])
                        os.rmdir(datapathcopy + 'bumenwenjian/' + option['bianhao'])
                    except Exception as e:
                        logger.error(e)
    logger.info("结束")
    return None


@app.route('/api/wenjianshanchu', methods=['POST'])
def wenjianshanchu():
    logger.info("开始")
    global quanjusuo
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    selectedOptions = parms['selectedOptions']
    bianhao = parms['bianhao']
    options = []
    while quanjusuo > 0 and quanjusuo < 600:
        quanjusuo += 1
        time.sleep(0.5)
    quanjusuo = 1
    try:
        options = es.get(index='bumenwenjian', doc_type='bumenwenjian', id='bumenwenjian')['_source']['options']
    except:
        logger.info("部门文件没有建")
        None
    newoptions = options
    for wenjianjia in selectedOptions:
        for option in newoptions:
            if option['label'] == wenjianjia:
                newoptions = option['children']
                break
    for i in range(len(newoptions) - 1, -1, -1):
        option = newoptions[i]
        if option['bianhao'] == bianhao:
            if option['type'] != '':
                isExists = os.path.exists(datapath + 'bumenwenjian/' + bianhao)
                if isExists:
                    for root, dirs, files in os.walk(os.path.join(datapath, 'bumenwenjian/' + bianhao)):
                        for file in files:
                            try:
                                os.remove(os.path.join(root, file))
                                os.remove(datapathcopy + 'bumenwenjian/' + bianhao + '/' + file)
                            except Exception as e:
                                logger.error(e)
                    try:
                        os.rmdir(datapath + 'bumenwenjian/' + bianhao)
                        os.rmdir(datapathcopy + 'bumenwenjian/' + bianhao)
                    except Exception as e:
                        logger.error(e)
            else:
                deletewenjianjia(option)
            newoptions.pop(i)
    es.index(index='bumenwenjian', doc_type='bumenwenjian', id='bumenwenjian', body={'options': options})
    quanjusuo = 0
    logger.info("结束")
    return json.dumps({'options': options, 'files': newoptions})


@app.route('/api/setchangyongzu', methods=['POST'])
def setchangyongzu():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    changyongzu = parms['changyongzu']
    toData = parms['toData']
    tongxinlu = []
    for group in usertongxinlu:
        if group['id'] == changyongzu:
            logger.info("结束")
            return json.dumps({'MSG': 'NO'})
    doc = []
    try:
        doc = es.get(index='changyongzu', doc_type='changyongzu', id=userid)['_source']['changyongzulist']
    except:
        logger.info("常用组没有建")
        None
    for group in doc:
        if group['id'] == changyongzu:
            logger.info("结束")
            return json.dumps({'MSG': 'NO'})
    newchangyongzu = {}
    newchangyongzu['id'] = changyongzu
    newchangyongzu['pid'] = 0
    newchangyongzu['label'] = changyongzu
    newchangyongzu['children'] = []
    for group in toData:
        for user in group['children']:
            user['id'] = time.strftime("%Y%m%d%H%M%S", time.localtime()) + str(
                random.randint(10000000000000, 99999999999999))
            user['pid'] = changyongzu
            newchangyongzu['children'].append(user)
    doc.append(newchangyongzu)
    es.index(index='changyongzu', doc_type='changyongzu', id=userid, body={'changyongzulist': doc})
    logger.info("结束")
    return json.dumps({'MSG': 'YES', 'changyongzulist': doc})


@app.route('/api/getchangyongzu', methods=['POST'])
def getchangyongzu():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    doc = []
    try:
        doc = es.get(index='changyongzu', doc_type='changyongzu', id=userid)['_source']['changyongzulist']
    except:
        logger.info("常用组没有建")
        None
    logger.info("结束")
    return json.dumps({'MSG': 'YES', 'changyongzulist': doc})


@app.route('/api/xiugaichangyongzu', methods=['POST'])
def xiugaichangyongzu():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    changyongzulist = parms['changyongzulist']
    es.index(index='changyongzu', doc_type='changyongzu', id=userid, body={'changyongzulist': changyongzulist})
    logger.info("结束")
    return "OK"


@app.route('/api/shanchurenyuan', methods=['POST'])
def shanchurenyuan():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    if userinfo[userid]['quanxian'] != 60 and userinfo[userid]['quanxian'] != 28:
        logger.info("结束")
        return "OK"
    shanchuto = parms['shanchuto']
    for group in shanchuto:
        for user in group['children']:
            try:
                if userinfo[user['userid']]['quanxian'] == 28: continue
                es.delete(index='userinfo', doc_type='userinfo', id=user['userid'])
            except Exception as e:
                logger.error(e)
    updatausers()
    logger.info("结束")
    return json.dumps({'MSG': 'YES'})


@app.route('/api/xinjianbumen', methods=['POST'])
def xinjianbumen():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    if userinfo[userid]['quanxian'] != 60 and userinfo[userid]['quanxian'] != 28:
        logger.info("结束")
        return "OK"
    bumenmingcheng = parms['bumenmingcheng']
    xinjianto = parms['xinjianto']
    for group in xinjianto:
        for user in group['children']:
            try:
                doc = es.get(index='userinfo', doc_type='userinfo', id=user['userid'])['_source']
                doc['group'] = bumenmingcheng
                es.index(index='userinfo', doc_type='userinfo', id=user['userid'], body=doc)
            except:
                logger.error("人员信息错乱")
                None
    updatausers()
    logger.info("结束")
    return json.dumps({'MSG': 'YES', 'tongxinlu': usertongxinlu})


@app.route('/api/xinzengrenyuan', methods=['POST'])
def xinzengrenyuan():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    if userinfo[userid]['quanxian'] != 60 and userinfo[userid]['quanxian'] != 28:
        logger.info("结束")
        return json.dumps({'MSG': 'NO'})
    newuser = parms['newuser']
    zhanghao = newuser['zhanghao'].copy()
    zhanghao = zhanghao.strip()
    newuser['zhanghao'] = ''
    for zimu in zhanghao:
        if zimu != ' ':
            newuser['zhanghao'] += zimu
    newuser['quanxian'] = int(newuser['quanxian'])
    try:
        es.get(index='userinfo', doc_type='userinfo', id=newuser['userid'])
        logger.info("结束")
        return json.dumps({'MSG': 'NO'})
    except:
        es.index(index='userinfo', doc_type='userinfo', id=newuser['userid'], body=newuser)
    updatausers()
    logger.info("结束")
    return json.dumps({'MSG': 'YES'})


@app.route('/api/piliangdaoru', methods=['POST'])
def piliangdaoru():
    logger.info("开始")
    upload_file = request.files['file']
    token = request.form.get('token')
    userid = token_userid[token]
    if int(userinfo[userid]['quanxian']) != 60 and userinfo[userid]['quanxian'] != 28:
        logger.info("结束")
        return json.dumps({'MSG': 'NO'})
    name = 'userinfo.csv'
    upload_file.save(datapath + name)
    open(datapathcopy + name, "wb").write(open(name, "rb").read())
    a = ['dianhua', 'email', 'group', 'name', 'phone', 'pwd', 'quanxian', 'userid', 'zhanghao', 'zhiweiname', 'neiwai']
    try:
        f = open(datapath + 'userinfo.csv', 'r', encoding='utf8')
        ff = csv.reader(f)
        flag = 0
        for line in ff:
            flag += 1
            if flag == 1: continue
            if len(line) == len(a):
                newuser = {}
                for i in range(len(a)):
                    newuser[a[i]] = line[i]
                newuser['quanxian'] = int(newuser['quanxian'])
                try:
                    doc = es.get(index='userinfo', doc_type='userinfo', id=newuser['userid'])['_source']
                    doc.update(newuser)
                    es.index(index='userinfo', doc_type='userinfo', id=newuser['userid'], body=doc)
                except Exception as e:
                    es.index(index='userinfo', doc_type='userinfo', id=newuser['userid'], body=newuser)
        f.close()
        logger.info("结束")
        return json.dumps({'MSG': 'YES'})
    except Exception as e:
        try:
            f = open(datapath + 'userinfo.csv', 'r', encoding='gbk')
            ff = csv.reader(f)
            flag = 0
            for line in ff:
                flag += 1
                if flag == 1: continue
                if len(line) == len(a):
                    newuser = {}
                    for i in range(len(a)):
                        newuser[a[i]] = line[i]
                    newuser['quanxian'] = int(newuser['quanxian'])
                    try:
                        doc = es.get(index='userinfo', doc_type='userinfo', id=newuser['userid'])['_source']
                        doc.update(newuser)
                        es.index(index='userinfo', doc_type='userinfo', id=newuser['userid'], body=doc)
                    except Exception as e:
                        es.index(index='userinfo', doc_type='userinfo', id=newuser['userid'], body=doc)
            f.close()
            logger.info("结束")
            return json.dumps({'MSG': 'YES'})
        except Exception as e:
            logger.info("结束")
            return json.dumps({'MSG': 'NO'})


@app.route('/api/getifzaixian', methods=['POST'])
def getifzaixian():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    if token in token_userid:
        logger.info("结束")
        return json.dumps({'MSG': 'YES'})
    logger.info("结束")
    return json.dumps({'MSG': 'NO'})


@app.route('/api/chaxunwendang', methods=['POST'])
def chaxunwendang():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    if userinfo[userid]['quanxian'] == 28 or userinfo[userid]['quanxian'] == 60:
        wendangid = parms['wendangid']
        try:
            doc = es.get(index='wendang', doc_type='wendang', id=wendangid)['_source']
            logger.info("结束")
            return json.dumps({'MSG': 'YES', 'dataTable': [doc]})
        except:
            try:
                doc = es.get(index='mindoc', doc_type='mindoc', id=wendangid)['_source']
                logger.info("结束")
                return json.dumps({'MSG': 'YES', 'dataTable': [doc]})
            except:
                logger.info("结束")
                return json.dumps({'MSG': 'NO', 'dataTable': []})
    else:
        logger.info("结束")
        return json.dumps({'MSG': 'NO', 'dataTable': []})


@app.route('/api/shanchuwendang', methods=['POST'])
def shanchuwendang():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    if userinfo[userid]['quanxian'] == 28 or userinfo[userid]['quanxian'] == 60:
        wendangid = parms['wendangid']
        try:
            doc = es.get(index='wendang', doc_type='wendang', id=wendangid)['_source']
            shenpihis = doc['shenpihis']
            for newuser in shenpihis:
                try:
                    newdoc = es.get(index='jieshouwendang', doc_type='jieshouwendang', id=newuser)['_source']
                    newdoc.pop(wendangid)
                    es.index(index='jieshouwendang', doc_type='jieshouwendang', id=newuser, body=newdoc)
                except:
                    logger.error("文档和审批信息错乱")
                    None
            isExists = os.path.exists('fujian/' + wendangid)
            if isExists:
                for root, dirs, files in os.walk(os.path.join(datapath, 'fujian/' + wendangid)):
                    for file in files:
                        try:
                            os.remove(os.path.join(root, file))
                            os.remove(datapathcopy + 'fujian/' + wendangid + '/' + file)
                        except:
                            logger.error("和备份系统不同步")
                            None
                try:
                    os.rmdir(datapath + 'fujian/' + wendangid)
                    os.rmdir(datapathcopy + 'fujian/' + wendangid)
                except:
                    logger.error("和备份系统不同步")
                    None
            es.delete(index='wendang', doc_type='wendang', id=wendangid)
            logger.info("结束")
            return json.dumps({'MSG': 'YES'})
        except:
            try:
                doc = es.get(index='mindoc', doc_type='mindoc', id=wendangid)['_source']
                shenpihis = doc['shenpihis']
                for newuser in shenpihis:
                    newdoc = es.get(index='jieshoumindoc', doc_type='jieshoumindoc', id=newuser)['_source']
                    newdoc.pop(wendangid)
                    es.index(index='jieshoumindoc', doc_type='jieshoumindoc', id=newuser, body=newdoc)
                isExists = os.path.exists('fujian/' + wendangid)
                if isExists:
                    for root, dirs, files in os.walk(os.path.join(datapath, 'fujian/' + wendangid)):
                        for file in files:
                            try:
                                os.remove(os.path.join(root, file))
                                os.remove(datapathcopy + 'fujian/' + wendangid + '/' + file)
                            except:
                                logger.error("和备份系统不同步")
                                None
                    try:
                        os.rmdir(datapath + 'fujian/' + wendangid)
                        os.rmdir(datapathcopy + 'fujian/' + wendangid)
                    except:
                        logger.error("和备份系统不同步")
                        None
                es.delete(index='mindoc', doc_type='mindoc', id=wendangid)
                logger.info("结束")
                return json.dumps({'MSG': 'YES'})
            except:
                logger.info("结束")
                return json.dumps({'MSG': 'NO'})
    else:
        logger.info("结束")
        return json.dumps({'MSG': 'NO'})


@app.route('/api/getyouqinglist', methods=['POST'])
def getyouqinglist():
    logger.info("开始")
    f = open('youqinglist.json', 'r', encoding='utf8')
    youqinglist = {}
    for line in f.readlines():
        youqinglist = json.loads(line)
        break
    f.close()
    logger.info("结束")
    return json.dumps({'youqinglist': youqinglist})


@app.route('/api/setyouqinglist', methods=['POST'])
def setyouqinglist():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    if userinfo[userid]['quanxian'] == 60 or userinfo[userid]['quanxian'] == 28:
        youqinglist = parms['youqinglist']
        if len(youqinglist[-1]['title']) == 0:
            youqinglist = youqinglist[:-1]
        for i in range(len(youqinglist)):
            if youqinglist[i]['url'][:4] != 'http':
                youqinglist[i]['url'] = 'http://' + youqinglist[i]['url']
        f = open(datapath + 'youqinglist.json', 'w', encoding='utf8')
        f.write(json.dumps(youqinglist, ensure_ascii=False))
        f.close()
        f = open(datapathcopy + 'youqinglist.json', 'w', encoding='utf8')
        f.write(json.dumps(youqinglist, ensure_ascii=False))
        f.close()
        logger.info("结束")
        return json.dumps({'MSG': 'YES'})
    else:
        logger.info("结束")
        return json.dumps({'MSG': 'NO'})


@app.route('/api/getdengluyelist', methods=['POST'])
def getdengluyelist():
    logger.info("开始")
    f = open('dengluyelist.json', 'r', encoding='utf8')
    dengluyelist = {}
    for line in f.readlines():
        dengluyelist = json.loads(line)
        break
    f.close()
    logger.info("结束")
    return json.dumps({'dengluyelist': dengluyelist})


@app.route('/api/setdengluyelist', methods=['POST'])
def setdengluyelist():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    if userinfo[userid]['quanxian'] == 60 or userinfo[userid]['quanxian'] == 28:
        dengluyelist = parms['dengluyelist']
        if len(dengluyelist[-1]['title']) == 0:
            dengluyelist = dengluyelist[:-1]
        f = open(datapath + 'dengluyelist.json', 'w', encoding='utf8')
        f.write(json.dumps(dengluyelist, ensure_ascii=False))
        f.close()
        f = open(datapathcopy + 'dengluyelist.json', 'w', encoding='utf8')
        f.write(json.dumps(dengluyelist, ensure_ascii=False))
        f.close()
        logger.info("结束")
        return json.dumps({'MSG': 'YES'})
    else:
        logger.info("结束")
        return json.dumps({'MSG': 'NO'})


@app.route('/api/getlunbotulist', methods=['POST'])
def getlunbotulist():
    logger.info("开始")
    f = open('lunbotulist.json', 'r', encoding='utf8')
    lunbotulist = {}
    for line in f.readlines():
        lunbotulist = json.loads(line)
        break
    f.close()
    logger.info("结束")
    return json.dumps({'lunbotulist': lunbotulist})


@app.route('/api/setlunbotulist', methods=['POST'])
def setlunbotulist():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    if userinfo[userid]['quanxian'] == 60 or userinfo[userid]['quanxian'] == 28:
        lunbotulist = parms['lunbotulist']
        if len(lunbotulist[-1]['url']) == 0:
            lunbotulist = lunbotulist[:-1]
        f = open(datapath + 'lunbotulist.json', 'w', encoding='utf8')
        f.write(json.dumps(lunbotulist, ensure_ascii=False))
        f.close()
        f = open(datapathcopy + 'lunbotulist.json', 'w', encoding='utf8')
        f.write(json.dumps(lunbotulist, ensure_ascii=False))
        f.close()
        logger.info("结束")
        return json.dumps({'MSG': 'YES'})
    else:
        logger.info("结束")
        return json.dumps({'MSG': 'NO'})


@app.route('/api/lunbotuUrl', methods=['POST'])
def lunbotuUrl():
    logger.info("开始")
    upload_file = request.files['file']
    token = request.form['token']
    xuhao = request.form['xuhao']
    name = 'shouye/' + str(random.randint(10000000000000, 99999999999999)) + '.jpg'
    upload_file.save(datapath + name)
    open(datapathcopy + name, "wb").write(open(name, "rb").read())
    logger.info("结束")
    return json.dumps({'lunbotuUrl': name, 'xuhao': xuhao})


@app.route('/api/fanhui', methods=['POST'])
def fanhui():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    nibanyijian = parms['nibanyijian']
    pishi = int(parms['pishi'])
    wendangid = parms['wendangid']
    doc = es.get(index='wendang', doc_type='wendang', id=wendangid)
    doc = doc['_source']
    doc['zhuangtai'] = '退文'
    doc['nibanyijian'] = nibanyijian
    nowtime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    jieshoudoc = es.get(index='jieshouwendang', doc_type='jieshouwendang', id=userid)['_source']
    jieshoudoc[wendangid]['wancheng'] = 1
    es.index(index='jieshouwendang', doc_type='jieshouwendang', id=userid, body=jieshoudoc)
    doc['shenpihis'][userid]['wancheng'] = 1
    doc['shenpihis'][userid]['endtime'] = nowtime
    doc['shenpihis'][userid]['caozuo'] = '已完成'
    liucheng = {}
    liucheng['userid'] = userid
    liucheng['name'] = userinfo[userid]['name']
    liucheng['time'] = nowtime
    liucheng['miaoshu'] = '退回上一级'
    doc['liuchenglist'].append(liucheng)
    if pishi > 0:
        qianming = {}
        qianming['time'] = nowtime
        qianming['yijian'] = parms['lingdaopishi']
        qianming['userid'] = userid
        qianming['name'] = userinfo[userid]['name']
        if doc['doctype'] == 'gouzhi':
            cailiao = parms['cailiao']
            caiwu = parms['caiwu']
            if len(caiwu):
                qianming['leixing'] = 1
                qianming['yijian'] = caiwu
            else:
                qianming['leixing'] = 0
                qianming['yijian'] = cailiao
        if userinfo[userid]['quanxian'] <= 20:
            try:
                qianming['imageurl'] = userinfo[userid]['qianmingUrl']
            except:
                qianming['imageurl'] = ""
        if doc['doctype'] == 'shouwen':
            doc['lingdaopishilist'].append(qianming)
        else:
            if pishi == 1:
                doc['biglingdaolist'].append(qianming)
            elif pishi == 2:
                doc['midlingdaolist'].append(qianming)
            elif pishi == 3:
                doc['minlingdaolist'].append(qianming)
            else:
                doc['falvlingdaolist'].append(qianming)
    for newuser in doc['shenpihis']:
        doc['shenpihis'][newuser]['endtime'] = nowtime
        doc['shenpihis'][newuser]['wancheng'] = 1
        doc['shenpihis'][newuser]['caozuo'] = '已完成'
        newdoc = es.get(index='jieshouwendang', doc_type='jieshouwendang', id=newuser)['_source']
        newdoc[wendangid]['wancheng'] = 1
        es.index(index='jieshouwendang', doc_type='jieshouwendang', id=newuser, body=newdoc)
    laiwenuserid = doc['shenpihis'][userid]['laiwenuserid']
    try:
        jieshoudoc = es.get(index='jieshouwendang', doc_type='jieshouwendang', id=laiwenuserid)['_source']
        newdict = {}
        newdict['laiwentime'] = nowtime
        newdict['laiwenren'] = userinfo[userid]['name']
        newdict['doctype'] = doc['doctype']
        newdict['wancheng'] = 0
        jieshoudoc[wendangid] = newdict
        es.index(index='jieshouwendang', doc_type='jieshouwendang', id=laiwenuserid, body=jieshoudoc)
    except:
        newdict = {}
        newdict['laiwentime'] = nowtime
        newdict['laiwenren'] = userinfo[userid]['name']
        newdict['doctype'] = doc['doctype']
        newdict['wancheng'] = 0
        jieshoudoc = {wendangid: newdict}
        es.index(index='jieshouwendang', doc_type='jieshouwendang', id=laiwenuserid, body=jieshoudoc)
    doc['shenpihis'][laiwenuserid]['wancheng'] = 0
    doc['shenpihis'][laiwenuserid]['caozuo'] = '未完成'
    es.index(index='wendang', doc_type='wendang', id=wendangid, body=doc)
    logger.info("结束")
    return "OK"


@app.route('/api/chehui', methods=['POST'])
def chehui():
    logger.info("开始")
    parms = json.loads(str(request.stream.read(), encoding='utf8'))
    token = parms['token']
    userid = token_userid[token]
    wendangid = parms['wendangid']
    doc = es.get(index='wendang', doc_type='wendang', id=wendangid)
    doc = doc['_source']
    nowtime = time.strftime("%Y-%m-%d %H:%M:%S", time.localtime())
    liucheng = {}
    liucheng['userid'] = userid
    liucheng['name'] = userinfo[userid]['name']
    liucheng['time'] = nowtime
    liucheng['miaoshu'] = '撤回'
    doc['liuchenglist'].append(liucheng)
    doc['zhuangtai'] = '审批中'
    shenpihis = doc['shenpihis'].copy()
    for newuser in shenpihis:
        if shenpihis[newuser]['laiwenuserid'] == userid:
            newdoc = es.get(index='jieshouwendang', doc_type='jieshouwendang', id=newuser)['_source']
            newdoc.pop(wendangid)
            es.index(index='jieshouwendang', doc_type='jieshouwendang', id=newuser, body=newdoc)
            doc['shenpihis'].pop(newuser)
    try:
        jieshoudoc = es.get(index='jieshouwendang', doc_type='jieshouwendang', id=userid)['_source']
        jieshoudoc[wendangid]['wancheng'] = 0
        es.index(index='jieshouwendang', doc_type='jieshouwendang', id=userid, body=jieshoudoc)
    except:
        newdict = {}
        newdict['laiwentime'] = nowtime
        newdict['laiwenren'] = userinfo[userid]['name']
        newdict['doctype'] = doc['doctype']
        newdict['wancheng'] = 0
        jieshoudoc = {wendangid: newdict}
        es.index(index='jieshouwendang', doc_type='jieshouwendang', id=userid, body=jieshoudoc)
    if userid in doc['shenpihis']:
        doc['shenpihis'][userid]['wancheng'] = 0
    else:
        shenpi = {}
        shenpi['name'] = userinfo[userid]['name']
        shenpi['laiwenuserid'] = userid
        shenpi['laiwenren'] = userinfo[userid]['name']
        shenpi['laiwentime'] = nowtime
        shenpi['endtime'] = '-'
        shenpi['wancheng'] = 0
        shenpi['caozuo'] = '未完成'
        shenpi['cishu'] = 2
        doc['shenpihis'][userid] = shenpi
    if doc['doctype'] != 'shouwen':
        if userinfo[userid]['quanxian'] < 20:
            for (index, qianming) in enumerate(doc['biglingdaolist']):
                if qianming['userid'] == userid:
                    doc['biglingdaolist'].pop(index)
                    break
        elif userinfo[userid]['quanxian'] == 20:
            for (index, qianming) in enumerate(doc['midlingdaolist']):
                if qianming['userid'] == userid:
                    doc['midlingdaolist'].pop(index)
                    break
    else:
        for (index, qianming) in enumerate(doc['lingdaopishilist']):
            if qianming['userid'] == userid:
                doc['lingdaopishilist'].pop(index)
                break
    es.index(index='wendang', doc_type='wendang', id=wendangid, body=doc)
    logger.info("结束")
    return "OK"


if __name__ == '__main__':
    # server = pywsgi.WSGIServer(('127.0.0.1', 16888), app)
    # server.serve_forever()
    app.run(threaded=True, host='0.0.0.0', port=16888, debug=True)
