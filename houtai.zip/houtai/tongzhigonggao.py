import json
import time
import random
from elasticsearch import Elasticsearch
import os
from pypinyin import lazy_pinyin

datapath = '/Users/pangyuming/Desktop/'
os.chdir(datapath)


es = Elasticsearch([{"host": "localhost", "port": 9200, "timeout": 3600}])
search = {"query": {"match_all": {}}}
Docs=es.search(index='userinfo',doc_type='userinfo',body=search,size=10000)['hits']['hits']
userinfo={}
for doc in Docs:
    doc=doc['_source']
    userinfo[doc['userid']]=doc
Docs=es.search(index='mindoc',doc_type='mindoc',body=search,size=10000)['hits']['hits']
for doc in Docs:
    doc=doc['_source']
    shenpihis=json.loads(doc['shenpihis'])
    for shenpi in shenpihis:
        try:
            shenpihis[shenpi]['name']=userinfo[shenpi]['name']
        except:
            None
    doc['shenpihis']=json.dumps(shenpihis,ensure_ascii=False)
    es.index(index='mindoc',doc_type='mindoc',id=doc['wendangid'],body=doc)


es = Elasticsearch([{"host": "localhost", "port": 9200, "timeout": 3600}])
search = {"query": {"match_all": {}}}
Docs=es.search(index='mindoc',doc_type='mindoc',body=search,size=10000)['hits']['hits']
for doc in Docs:
    doc=doc['_source']
    if doc['doctype']=='youjian':
        doc['huifu']=''
        doc['huifuList']=[]
        es.index(index='mindoc',doc_type='mindoc',id=doc['wendangid'],body=doc)

